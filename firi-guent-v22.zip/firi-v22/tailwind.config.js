export default {
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Amiri','Georgia','serif'],
        body: ['"Cormorant Garamond"','Georgia','serif'],
        arabic: ['"Scheherazade New"','Amiri','serif'],
      },
    },
  },
  plugins: [],
}
