// ─── netlify/functions/journal-mensuel.js ────────────────────────
// Génère le rapport psycho-spirituel mensuel pour un abonné.
// Appelé manuellement (ou via Make webhook) en fin de mois.
// POST { userId, dreams: [{text, emotion, time, date}], userEmail }

const CLAUDE_MODEL = 'claude-sonnet-4-20250514'

const SYSTEM_JOURNAL = `Tu es Sheikh Momar, psychologue spirituel islamique et expert en interprétation des rêves selon Ibn Sirin et Al-Nabulsi.

Tu reçois la liste des rêves d'un croyant pour le mois écoulé. Tu dois produire un RAPPORT MENSUEL PSYCHO-SPIRITUEL complet et personnel.

Structure obligatoire du rapport :

**📔 JOURNAL DES RÊVES — RAPPORT MENSUEL**
**بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ**

**1. Vue d'ensemble du mois spirituel**
[Synthèse générale de la vie psycho-spirituelle du rêveur ce mois. Ton : bienveillant, professionnel, comme un psychologue et imam à la fois.]

**2. Thèmes récurrents identifiés**
[Liste les symboles qui reviennent : eau, lumière, serpent, maison, etc. Explique ce que la récurrence signifie selon Ibn Sirin.]

**3. Évolution émotionnelle du mois**
[Analyse l'évolution des émotions dans les rêves : peur → sérénité ? tension → apaisement ? Que dit cette évolution de l'état spirituel du rêveur ?]

**4. Rêve le plus significatif du mois**
[Identifie le rêve le plus important et explique pourquoi il est central.]

**5. Signes divins et avertissements**
[Y a-t-il des Ru'ya Rahmâniyya (rêves véridiques) ? Des avertissements à prendre au sérieux ? Sois précis et bienveillant.]

**6. Prescription spirituelle du mois**
[Recommandations pratiques et spirituelles personnalisées : dhikr, sadaqa, Istikhar, lectures coraniques spécifiques.]

**7. Du'a personnalisé**
[Dua en arabe + phonétique + traduction, adapté à la situation du rêveur ce mois.]

**8. Mot du Sheikh pour le mois prochain**
[Message d'espoir, d'encouragement et de guidance pour le mois à venir. Rappel de la miséricorde d'Allah.]

**وَاللَّهُ أَعْلَمُ — Wallahu A'lam**

Minimum 800 mots. Ton chaleureux, précis, professionnel. En français avec termes arabes translittérés.`

exports.handler = async (event) => {
  const origin = event.headers.origin || '*'
  const headers = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' }
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }

  const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY
  if (!ANTHROPIC_KEY) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Config manquante.' }) }

  let body
  try { body = JSON.parse(event.body) } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Corps invalide.' }) }
  }

  const { dreams, userEmail, month } = body
  if (!dreams || !Array.isArray(dreams) || dreams.length === 0) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Liste de rêves requise.' }) }
  }

  // Construire le message avec tous les rêves du mois
  const dreamsText = dreams.map((d, i) =>
    `Rêve ${i+1} (${d.date || 'date inconnue'}) :\n"${d.text}"\nÉmotion : ${d.emotion || 'non précisée'} · Moment : ${d.time || 'non précisé'}`
  ).join('\n\n---\n\n')

  const userMessage = `Génère le rapport mensuel pour ce croyant (${userEmail || 'anonyme'}).
Mois analysé : ${month || 'mois écoulé'}
Nombre de rêves ce mois : ${dreams.length}

${dreamsText}`

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: 3000,
        system: SYSTEM_JOURNAL,
        messages: [{ role: 'user', content: userMessage }],
      }),
    })

    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      return { statusCode: res.status, headers, body: JSON.stringify({ error: err?.error?.message ?? 'Erreur API' }) }
    }

    const data = await res.json()
    const text = data?.content?.[0]?.text ?? ''
    if (!text) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Réponse vide.' }) }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        report: text,
        dreamCount: dreams.length,
        userEmail,
        month,
        generatedAt: new Date().toISOString(),
      })
    }

  } catch (e) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: `Service indisponible: ${e.message}` }) }
  }
}
