// ─── netlify/functions/analyze.js v2 ─────────────────────────────
// Proxy Claude sécurisé.
// Priorité : ANTHROPIC_API_KEY en variable d'env → fallback serveur

const CLAUDE_MODEL     = 'claude-sonnet-4-20250514'
const FALLBACK_API_KEY = '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'

exports.handler = async (event) => {
  const origin = event.headers.origin || '*'
  const headers = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' }
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }

  // Variable d'env prioritaire, fallback serveur sinon
  const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || FALLBACK_API_KEY

  let body
  try { body = JSON.parse(event.body) } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Corps de requête invalide.' }) }
  }

  const { system, userMessage, premium } = body
  if (!userMessage || !system) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Paramètres manquants.' }) }
  }

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: premium ? 4000 : 1800,
        system,
        messages: [{ role: 'user', content: userMessage }],
      }),
    })

    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      return { statusCode: res.status, headers, body: JSON.stringify({ error: err?.error?.message ?? `Erreur API (${res.status})` }) }
    }

    const data = await res.json()
    const text = data?.content?.[0]?.text ?? ''
    if (!text) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Réponse vide. Réessayez.' }) }

    return { statusCode: 200, headers, body: JSON.stringify({ text, premium, ts: Date.now() }) }

  } catch (e) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: `Service indisponible: ${e.message}` }) }
  }
}
