// ─── netlify/functions/airtable-proxy.js v2 ──────────────────────
// Proxy Airtable sécurisé.
// Priorité : variables d'env Netlify → fallback hardcodé serveur
// Les credentials restent côté serveur, jamais dans le bundle client.

const FALLBACK_TOKEN   = 'pat44JBegA9gLiN7l.c87d07601f5d85124ba32010815cec3897223fa4fe5bfc7aaacd3bc14c6891af'
const FALLBACK_BASE_ID = 'appq95FX5MCVrrVWJ'

exports.handler = async (event) => {
  const origin = event.headers.origin || '*'
  const headers = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' }
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }

  // Variables d'env en priorité, fallback serveur sinon
  const TOKEN   = process.env.AIRTABLE_TOKEN   || FALLBACK_TOKEN
  const BASE_ID = process.env.AIRTABLE_BASE_ID || FALLBACK_BASE_ID

  let body
  try { body = JSON.parse(event.body) } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Corps invalide.' }) }
  }

  const { table, qs = '', method = 'GET', payload = null } = body
  if (!table) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Table requise.' }) }

  const url = `https://api.airtable.com/v0/${BASE_ID}/${encodeURIComponent(table)}${qs}`
  const opts = {
    method,
    headers: { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
  }
  if (payload) opts.body = JSON.stringify(payload)

  try {
    const res = await fetch(url, opts)
    const data = await res.json().catch(() => ({}))
    return { statusCode: res.status, headers, body: JSON.stringify(data) }
  } catch (e) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: `Airtable injoignable: ${e.message}` }) }
  }
}
