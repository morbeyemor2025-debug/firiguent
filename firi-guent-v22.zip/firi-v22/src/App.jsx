import React from 'react'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from './utils/AuthContext.jsx'
import Navbar    from './components/Navbar.jsx'
import Footer    from './components/Footer.jsx'
import Home      from './pages/Home.jsx'
import Login     from './pages/Login.jsx'
import Interpret from './pages/Interpret.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Admin     from './pages/Admin.jsx'
import AsmaulHusna from './pages/AsmaulHusna.jsx'

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg)' }}>
      <div style={{ textAlign:'center' }}>
        <div style={{ fontSize:48, marginBottom:12 }}>🌙</div>
        <div className="spin" style={{ margin:'0 auto' }}/>
      </div>
    </div>
  )
  if (!user) return <Navigate to="/login" replace />
  return children
}

function Layout() {
  const { pathname } = useLocation()
  const isAdmin  = pathname === '/admin'
  const isLogin  = pathname === '/login'
  const isDark   = pathname === '/' || isLogin

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column', background:'var(--bg)' }}>
      {!isAdmin && !isLogin && <Navbar />}
      <main style={{ flex:1 }}>
        <Routes>
          <Route path="/"            element={<Home />} />
          <Route path="/login"       element={<Login />} />
          <Route path="/interpreter" element={<ProtectedRoute><Interpret /></ProtectedRoute>} />
          <Route path="/dashboard"   element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/asmaul-husna" element={<AsmaulHusna />} />
          <Route path="/admin"       element={<Admin />} />
          <Route path="*"            element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      {!isAdmin && !isLogin && <Footer />}
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Layout />
      </BrowserRouter>
    </AuthProvider>
  )
}
