import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Clock, Plus, Search, Download, ChevronDown, ChevronUp } from 'lucide-react'
import { useAuth } from '../utils/AuthContext.jsx'
import { freeRemainingThisMonth } from '../utils/auth.js'
import { getUserInterpretations } from '../utils/airtable.js'
import { fmtDate } from '../utils/storage.js'
import { PACKS, waPayLink } from '../utils/constants.js'

const WaIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

export default function Dashboard() {
  const { user } = useAuth()
  const [interps, setInterps]   = useState([])
  const [loading, setLoading]   = useState(true)
  const [expanded, setExpanded] = useState(null)
  const [search, setSearch]     = useState('')

  useEffect(() => {
    if (!user?.id) { setLoading(false); return }
    getUserInterpretations(user.id)
      .then(records => {
        setInterps(records.map(r => ({ id:r.id, ...r.fields })))
      })
      .catch(() => setInterps([]))
      .finally(() => setLoading(false))
  }, [user?.id])

  const filtered = interps.filter(i =>
    !search.trim() || i.dream_text?.toLowerCase().includes(search.toLowerCase())
  )

  // Status label
  const statusLabel = () => {
    if (user?.plan === 'subscription') {
      const end = new Date(user.subscription_end)
      const days = Math.ceil((end - new Date()) / 86400000)
      return `♾️ Abonnement actif · expire dans ${days} jour${days>1?'s':''}`
    }
    if (Number(user?.credits) > 0) return `💎 ${user.credits} crédit${user.credits>1?'s':''} restant${user.credits>1?'s':''}`
    const remaining = freeRemainingThisMonth(user?.id)
    if (remaining > 0) return `🎁 ${remaining} interprétation${remaining>1?'s':''} gratuite${remaining>1?'s':''} ce mois`
    return '🔒 Aucun crédit — Rechargez votre compte'
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', paddingTop:80, paddingBottom:64, padding:'80px 16px 64px' }}>
      <div style={{ maxWidth:680, margin:'0 auto' }}>

        {/* Header */}
        <div style={{ textAlign:'center', marginBottom:24 }}>
          <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:'1.3rem', color:'var(--gold)', direction:'rtl', marginBottom:2 }}>سِجِلُّ الرُّؤَى</div>
          <h1 style={{ fontFamily:"'Amiri',serif", fontSize:'clamp(1.6rem,4vw,2rem)', fontWeight:700, color:'var(--text)', marginBottom:4 }}>
            Mes Interprétations
          </h1>
          <p style={{ color:'var(--text-muted)', fontSize:13 }}>{user?.email}</p>
        </div>

        {/* Status card */}
        <div className="card" style={{ padding:'16px 20px', marginBottom:16, display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
          <p style={{ fontSize:14, fontWeight:600, color:'var(--text-2)', margin:0 }}>{statusLabel()}</p>
          {(freeRemainingThisMonth(user?.id) === 0 && Number(user?.credits||0) === 0 && user?.plan !== 'subscription') && (
            <a href={waPayLink(PACKS[0], user?.email, '')} target="_blank" rel="noreferrer"
              className="btn btn-wa" style={{ padding:'8px 16px', fontSize:13, borderRadius:10, display:'flex', alignItems:'center', gap:6 }}>
              <WaIcon/> Recharger
            </a>
          )}
          <Link to="/interpreter" className="btn btn-primary" style={{ padding:'8px 16px', fontSize:13, borderRadius:10 }}>
            <Plus size={14}/> Nouveau rêve
          </Link>
        </div>

        {/* Stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10, marginBottom:20 }}>
          {[
            { label:'Rêves analysés', value:interps.length, icon:'🌙' },
            { label:'Ce mois', value:interps.filter(i=>{ const d=new Date(i.created_at),n=new Date(); return d.getMonth()===n.getMonth()&&d.getFullYear()===n.getFullYear() }).length, icon:'📅' },
            { label:'Crédits', value: user?.plan==='subscription'?'∞':Number(user?.credits||0), icon:'💎' },
          ].map((s,i) => (
            <div key={i} className="card" style={{ padding:'14px', textAlign:'center' }}>
              <div style={{ fontSize:20, marginBottom:4 }}>{s.icon}</div>
              <div style={{ fontFamily:"'Amiri',serif", fontSize:22, fontWeight:700, color:'var(--text)' }}>{s.value}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Search */}
        <div style={{ position:'relative', marginBottom:16 }}>
          <Search size={14} style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)', pointerEvents:'none' }}/>
          <input type="text" value={search} onChange={e=>setSearch(e.target.value)}
            className="field" style={{ paddingLeft:36, paddingTop:10, paddingBottom:10, fontSize:13 }}
            placeholder="Rechercher dans vos rêves…"/>
        </div>

        {/* List */}
        {loading ? (
          <div style={{ textAlign:'center', padding:48 }}>
            <div className="spin" style={{ margin:'0 auto' }}/>
            <p style={{ color:'var(--text-muted)', marginTop:16, fontSize:13 }}>Chargement depuis Airtable…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="card" style={{ padding:48, textAlign:'center' }}>
            <div className="float" style={{ fontSize:48, marginBottom:12 }}>🌙</div>
            <h3 style={{ fontFamily:"'Amiri',serif", fontSize:'1.3rem', fontWeight:600, color:'var(--text)', marginBottom:8 }}>
              {search ? 'Aucun résultat' : 'Aucun rêve analysé encore'}
            </h3>
            <p style={{ color:'var(--text-muted)', fontSize:13, marginBottom:20 }}>
              {search ? `Pas de rêve pour "${search}"` : 'Votre premier rêve vous attend.'}
            </p>
            <Link to="/interpreter" className="btn btn-primary" style={{ padding:'12px 28px', borderRadius:12 }}>
              <Plus size={15}/> Interpréter un rêve
            </Link>
          </div>
        ) : (
          <div>
            {filtered.map(interp => (
              <div key={interp.id} className="card" style={{ overflow:'hidden', marginBottom:10 }}>
                <div style={{ padding:'16px 20px', cursor:'pointer' }} onClick={() => setExpanded(expanded===interp.id ? null : interp.id)}>
                  <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6, flexWrap:'wrap' }}>
                        <span style={{ fontSize:11, color:'var(--text-muted)', display:'flex', alignItems:'center', gap:4 }}>
                          <Clock size={10}/>{fmtDate(interp.created_at)}
                        </span>
                      </div>
                      <p style={{ fontSize:14, color:'var(--text-2)', fontStyle:'italic', margin:0, overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>
                        "{interp.dream_text}"
                      </p>
                    </div>
                    <span style={{ color:'var(--text-muted)', flexShrink:0, paddingTop:2 }}>
                      {expanded===interp.id ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}
                    </span>
                  </div>
                </div>
                {expanded===interp.id && (
                  <div style={{ borderTop:'1px solid #f3f4f6', padding:'16px 20px' }}>
                    <div style={{ fontSize:13, color:'var(--text-3)', lineHeight:1.75, whiteSpace:'pre-wrap', maxHeight:300, overflowY:'auto' }}>
                      {interp.result}
                    </div>
                    <div style={{ marginTop:14 }}>
                      <div className="arabic-block" style={{ display:'inline-flex' }}>
                        <div className="arabic-script" style={{ fontSize:'1.1rem' }}>وَاللَّهُ أَعْلَمُ</div>
                        <div className="arabic-translation">Seul Allah connaît la vérité</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
