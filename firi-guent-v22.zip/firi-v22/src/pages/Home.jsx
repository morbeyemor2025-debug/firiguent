// ─── Home.jsx v21 — Luxe Arabesque ───────────────────────────────
import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Star, ChevronDown, ChevronUp, Lock, Zap, Shield, BookOpen, ArrowRight } from 'lucide-react'
import { PACKS, waPayLink, waExpertLink, PRICING } from '../utils/constants.js'
import PrayerWidget from '../components/PrayerWidget.jsx'
import IslamicCalendar from '../components/IslamicCalendar.jsx'

const WaIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

const TESTIMONIALS = [
  { avatar:'https://i.ibb.co/pvx1ng1L/avatar-homme-noir-1.jpg', name:'Ibrahima S.', city:'Dakar', text:'J\'avais rêvé d\'un serpent depuis 3 semaines. Firi Guent m\'a expliqué exactement le signe. Ibn Sirin avait tout prédit. La réponse m\'a changé.' },
  { avatar:'https://i.ibb.co/SXjgNHCz/avatar-femme.jpg', name:'Aïssatou K.', city:'Saint-Louis', text:'L\'analyse complète en quelques minutes. La précision est incroyable. Ce rêve était un avertissement d\'Allah. Alhamdulillah, j\'ai évité un problème majeur.' },
  { avatar:'https://i.ibb.co/xRm4jfB/avatar-homme-blanc1.jpg', name:'Mamadou B.', city:'Thiès', text:'Sheikh Momar a cité exactement ce que mon imam m\'avait dit. Disponible à 2h du matin. Le service premium vaut largement son prix.' },
]

const FAQS = [
  { q:'Est-ce vraiment basé sur Ibn Sirin ?', a:'Oui. Chaque interprétation s\'appuie directement sur les œuvres d\'Ibn Sirin (Tafsir al-Ahlam) et d\'Al-Nabulsi (At-Ta\'bir fi ar-Ru\'ya). Les citations sont précises et vérifiables.' },
  { q:'Mon rêve est-il vraiment confidentiel ?', a:'Absolument. Vos rêves sont stockés uniquement sur votre appareil. Ils ne sont jamais partagés ni vendus. Seule l\'analyse est traitée de manière sécurisée.' },
  { q:'Comment fonctionne le paiement Wave ?', a:'Vous envoyez le montant par Wave, joignez une capture d\'écran dans le message WhatsApp avec la référence. Notre équipe confirme sous 5 minutes. Simple et sécurisé.' },
  { q:'Quelle est la différence entre gratuit et complet ?', a:'La version gratuite donne un aperçu à 40% : type de rêve et symbole principal. L\'analyse complète inclut tous les symboles secondaires, hadiths authentiques, cas des Compagnons ﷺ et prescriptions spirituelles.' },
  { q:'Le plan Pro dure combien de temps ?', a:'Le plan Pro vous donne 6 mois complets (180 jours) d\'accès illimité, plus le Journal mensuel des rêves — un rapport psycho-spirituel envoyé chaque fin de mois.' },
]

// ─── Ornement arabesque SVG ───────────────────────────────────────
const ArabesqueOrnament = ({ color = 'var(--gold)', size = 24 }) => (
  <svg width={size * 4} height={size / 2} viewBox="0 0 96 12" fill="none">
    <line x1="0" y1="6" x2="32" y2="6" stroke={color} strokeOpacity=".3" strokeWidth="0.8"/>
    <circle cx="38" cy="6" r="2" fill={color} fillOpacity=".5"/>
    <circle cx="48" cy="6" r="3.5" fill={color} fillOpacity=".7"/>
    <circle cx="58" cy="6" r="2" fill={color} fillOpacity=".5"/>
    <line x1="64" y1="6" x2="96" y2="6" stroke={color} strokeOpacity=".3" strokeWidth="0.8"/>
  </svg>
)

export default function Home() {
  const [openFaq, setOpenFaq] = useState(null)

  return (
    <div style={{ fontFamily:"'Cormorant Garamond',serif" }}>

      {/* ══════════════════════════════════════════════════════════
          HERO
      ══════════════════════════════════════════════════════════ */}
      <section style={{
        background:'var(--bg-hero)',
        minHeight:'100vh',
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        textAlign:'center', padding:'100px 20px 80px',
        position:'relative', overflow:'hidden',
      }}>
        {/* Motif géométrique */}
        <div className="geo" style={{ position:'absolute', inset:0, opacity:.6 }}/>

        {/* Lueur centrale */}
        <div style={{ position:'absolute', top:'30%', left:'50%', transform:'translate(-50%,-50%)', width:600, height:600, borderRadius:'50%', background:'radial-gradient(ellipse, rgba(139,105,20,.12) 0%, transparent 65%)', pointerEvents:'none' }}/>

        {/* Demi-lune déco */}
        <div style={{ position:'absolute', right:-80, top:80, fontSize:400, opacity:.025, lineHeight:1, userSelect:'none', pointerEvents:'none' }}>🌙</div>

        <div style={{ position:'relative', zIndex:1, maxWidth:740, width:'100%' }}>

          {/* Badge autorité */}
          <div className="up d1" style={{ marginBottom:24, display:'flex', justifyContent:'center' }}>
            <span style={{ fontFamily:"'Outfit',sans-serif", background:'rgba(139,105,20,.15)', color:'rgba(200,170,80,.9)', border:'1px solid rgba(139,105,20,.3)', borderRadius:100, padding:'7px 20px', fontSize:12, fontWeight:600, letterSpacing:'0.06em', textTransform:'uppercase' }}>
              🇸🇳 Ibn Sirin · Al-Nabulsi · Tradition islamique authentique
            </span>
          </div>

          {/* Titre */}
          <h1 className="up d2" style={{ color:'#F7F3EC', fontFamily:"'Cormorant Garamond',serif", fontSize:'clamp(2.4rem,7vw,5rem)', fontWeight:700, lineHeight:1.1, marginBottom:8, letterSpacing:'-0.02em' }}>
            Votre rêve n'est pas
            <br/>un hasard.
          </h1>
          <h2 className="up d2" style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:'clamp(1.6rem,4vw,2.8rem)', fontWeight:300, lineHeight:1.2, marginBottom:24, letterSpacing:'-0.01em' }}>
            <span className="gold-shimmer-text">Allah vous envoie un message.</span>
          </h2>

          {/* Hadith */}
          <div className="up d3" style={{ maxWidth:560, margin:'0 auto 32px' }}>
            <div style={{ background:'rgba(139,105,20,.1)', border:'1px solid rgba(139,105,20,.2)', borderRadius:14, padding:'16px 22px', position:'relative' }}>
              <div style={{ position:'absolute', top:0, left:0, right:0, height:1, background:'linear-gradient(to right, transparent, rgba(200,170,80,.4), transparent)' }}/>
              <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:'1.3rem', color:'rgba(200,170,80,.9)', direction:'rtl', marginBottom:8, lineHeight:1.6 }}>
                رُؤْيَا الْمُؤْمِنِ جُزْءٌ مِنْ سِتَّةٍ وَأَرْبَعِينَ جُزْءًا مِنَ النُّبُوَّةِ
              </div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", color:'rgba(186,230,172,.85)', fontSize:'1rem', fontStyle:'italic', lineHeight:1.5 }}>
                "Le rêve du croyant est une partie des 46 parties de la prophétie."
              </div>
              <div style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.35)', fontSize:11, marginTop:6, letterSpacing:'0.04em' }}>— Bukhari & Muslim</div>
            </div>
          </div>

          {/* CTAs */}
          <div className="up d4" style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:12 }}>
            <Link to="/login" style={{
              display:'inline-flex', alignItems:'center', gap:10,
              fontFamily:"'Outfit',sans-serif",
              fontSize:16, fontWeight:600, padding:'16px 40px', borderRadius:14,
              background:'linear-gradient(135deg, #C9A84C 0%, #E8C96A 40%, #B8860B 100%)',
              color:'#0F1D0D', textDecoration:'none', letterSpacing:'0.02em',
              boxShadow:'0 4px 24px rgba(139,105,20,.4)',
              transition:'all .25s',
            }}>
              🌙 Interpréter mon rêve — Gratuit
            </Link>
            <a href={waExpertLink('')} target="_blank" rel="noreferrer" style={{
              display:'inline-flex', alignItems:'center', gap:8,
              fontFamily:"'Outfit',sans-serif",
              fontSize:14, fontWeight:500, padding:'12px 28px', borderRadius:12,
              background:'rgba(255,255,255,.07)', color:'rgba(247,243,236,.75)',
              border:'1px solid rgba(255,255,255,.12)', textDecoration:'none',
            }}>
              <WaIcon size={14}/> Parler à un expert WhatsApp
            </a>
          </div>

          <p className="up d5" style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.3)', fontSize:12, marginTop:18, letterSpacing:'0.03em' }}>
            2 interprétations gratuites / mois · Confidentiel · Résultat immédiat
          </p>

          {/* Social proof */}
          <div className="up d5" style={{ marginTop:32, display:'flex', flexWrap:'wrap', justifyContent:'center', alignItems:'center', gap:12 }}>
            <div style={{ display:'flex' }}>
              {TESTIMONIALS.map((t,i) => (
                <img key={i} src={t.avatar} alt="" style={{ width:32, height:32, borderRadius:'50%', border:'2px solid rgba(139,105,20,.4)', objectFit:'cover', marginLeft: i === 0 ? 0 : -8 }}/>
              ))}
            </div>
            <span style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(200,170,80,.8)', fontSize:13, fontWeight:600 }}>+3 200 rêves interprétés</span>
            <div style={{ display:'flex', gap:2 }}>
              {[1,2,3,4,5].map(i => <Star key={i} size={13} fill="rgba(200,170,80,.7)" stroke="none"/>)}
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          POURQUOI — Symboles
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--bg-alt)', padding:'80px 20px' }}>
        <div style={{ maxWidth:780, margin:'0 auto', textAlign:'center' }}>
          <div className="label-sm" style={{ color:'#C1121F', marginBottom:12 }}>⚠️ Ce que vous ignorez peut-être</div>
          <h2 style={{ marginBottom:16, lineHeight:1.2 }}>
            Chaque nuit, vos rêves portent<br/>
            <em style={{ color:'var(--gold)', fontStyle:'italic' }}>des messages d'Allah.</em>
          </h2>
          <div style={{ margin:'0 auto 40px', display:'flex', justifyContent:'center' }}>
            <ArabesqueOrnament/>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:16 }}>
            {[
              { icon:'🐍', title:'Serpent dans la maison', text:'Un ennemi caché dans votre entourage que vous n\'avez pas encore identifié.' },
              { icon:'🌊', title:'Eau trouble', text:'Ibn Sirin : des épreuves imminentes approchent. Votre rêve vous prévenait.' },
              { icon:'🏠', title:'Maison qui s\'effondre', text:'Concerne souvent votre santé, votre famille ou votre foi. Rarement anodin.' },
              { icon:'🌙', title:'Voir le Prophète ﷺ', text:'L\'un des rêves les plus bénis. Mais seulement si vous en comprenez le message.' },
            ].map((item, i) => (
              <div key={i} className="card-luxury" style={{ padding:'22px 18px', textAlign:'left' }}>
                <div style={{ fontSize:28, marginBottom:12 }}>{item.icon}</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontWeight:700, color:'var(--text)', marginBottom:6, fontSize:17 }}>{item.title}</div>
                <p style={{ fontSize:13, lineHeight:1.65, margin:0, fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)' }}>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          SOLUTION — Features
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--card)', padding:'80px 20px' }}>
        <div style={{ maxWidth:920, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:52 }}>
            <div className="label-sm" style={{ color:'var(--emerald)', marginBottom:12 }}>La solution</div>
            <h2 style={{ marginBottom:14, lineHeight:1.2 }}>
              Firi Guent — L'interprétation islamique<br/>
              disponible <span style={{ color:'var(--gold)' }}>24h/24 au Sénégal</span>
            </h2>
            <p style={{ maxWidth:560, margin:'0 auto', fontSize:'1.05rem', fontFamily:"'Outfit',sans-serif" }}>
              1 400 ans de science islamique. Analyses rigoureuses selon Ibn Sirin et Al-Nabulsi.
              Disponible à 3h du matin quand votre rêve vous réveille.
            </p>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:18 }}>
            {[
              { icon:'📖', title:'Ibn Sirin & Al-Nabulsi', desc:'Citations exactes. Méthode millénaire préservée intacte. Aucune interprétation sans référence.', accent:'var(--gold)' },
              { icon:'⚡', title:'Réponse immédiate', desc:'Le symbole central identifié en secondes. Disponible à 3h du matin, 7j/7, même pendant le Ramadan.', accent:'var(--emerald)' },
              { icon:'🔒', title:'100% confidentiel', desc:'Vos rêves ne quittent jamais votre appareil. Seul Sheikh Momar a accès à votre rêve pour l\'analyser.', accent:'var(--gold)' },
              { icon:'🇸🇳', title:'Ancrage sénégalais', desc:'Nos experts locaux intègrent les valeurs mourides et tidjanes, le dhikr, la sadaqa, la guidance réelle.', accent:'var(--emerald)' },
            ].map((f, i) => (
              <div key={i} className="card-luxury" style={{ padding:'26px 22px', display:'flex', flexDirection:'column', gap:12 }}>
                <div style={{ width:46, height:46, borderRadius:12, background:`rgba(139,105,20,.08)`, border:`1px solid rgba(139,105,20,.15)`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>
                  {f.icon}
                </div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontWeight:700, color:'var(--text)', fontSize:18 }}>{f.title}</div>
                <p style={{ fontFamily:"'Outfit',sans-serif", fontSize:13, lineHeight:1.65, margin:0, color:'var(--text-muted)' }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          PRICING — 3 plans v21
      ══════════════════════════════════════════════════════════ */}
      <section id="pricing" style={{ background:'var(--bg)', padding:'88px 20px', position:'relative', overflow:'hidden' }}>
        <div className="geo-gold" style={{ position:'absolute', inset:0, opacity:.5 }}/>
        <div style={{ maxWidth:980, margin:'0 auto', position:'relative', zIndex:1 }}>

          <div style={{ textAlign:'center', marginBottom:56 }}>
            <div className="label-sm" style={{ color:'var(--gold)', marginBottom:12 }}>Tarifs</div>
            <h2 style={{ marginBottom:10 }}>Simple. Juste. <em style={{ color:'var(--gold)', fontStyle:'italic' }}>In sha Allah.</em></h2>
            <div style={{ display:'flex', justifyContent:'center', marginBottom:16 }}>
              <ArabesqueOrnament/>
            </div>
            <p style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)', maxWidth:480, margin:'0 auto', fontSize:'1rem' }}>
              Commencez gratuitement. Déverrouillez l'analyse complète quand vous êtes prêt.
            </p>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(275px,1fr))', gap:22, alignItems:'stretch' }}>

            {/* GRATUIT */}
            <div className="card" style={{ padding:'30px 26px', display:'flex', flexDirection:'column' }}>
              <div className="label-sm" style={{ color:'var(--text-muted)', marginBottom:14 }}>Découverte</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:46, fontWeight:700, color:'var(--text)', lineHeight:1, marginBottom:4 }}>Gratuit</div>
              <div style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-light)', fontSize:13, marginBottom:24 }}>2 interprétations / mois · Aperçu 40%</div>
              <ul style={{ listStyle:'none', padding:0, flex:1, marginBottom:24 }}>
                {PRICING.free.features.map((t,i) => (
                  <li key={i} style={{ display:'flex', gap:10, marginBottom:10, color:'var(--text-3)', fontSize:13, alignItems:'flex-start', fontFamily:"'Outfit',sans-serif" }}>
                    <span style={{ color:'var(--emerald)', fontWeight:700, flexShrink:0, marginTop:1 }}>✓</span>{t}
                  </li>
                ))}
                {PRICING.free.missing.slice(0,3).map((t,i) => (
                  <li key={i} style={{ display:'flex', gap:10, marginBottom:10, color:'#C4B9A8', fontSize:13, alignItems:'flex-start', fontFamily:"'Outfit',sans-serif" }}>
                    <span style={{ color:'#DDD5C5', flexShrink:0 }}>○</span>{t}
                  </li>
                ))}
              </ul>
              <Link to="/login" style={{
                display:'flex', alignItems:'center', justifyContent:'center',
                padding:'13px', borderRadius:12, border:'1.5px solid var(--emerald)',
                fontFamily:"'Outfit',sans-serif", fontSize:14, fontWeight:600,
                color:'var(--emerald)', textDecoration:'none',
                background:'transparent', transition:'all .2s',
              }}>
                Commencer gratuitement
              </Link>
            </div>

            {/* ONCE — Populaire */}
            <div style={{
              padding:'30px 26px', display:'flex', flexDirection:'column',
              borderRadius:20, position:'relative', overflow:'hidden',
              border:'2px solid var(--emerald)',
              background:'var(--card)',
              boxShadow:'0 8px 40px rgba(11,77,46,.15)',
            }}>
              {/* Barre top émeraude */}
              <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:'linear-gradient(to right, var(--emerald-mid), var(--emerald-hover))' }}/>
              <div style={{ position:'absolute', top:14, right:16, background:'var(--emerald)', color:'#F0FDF4', borderRadius:100, padding:'3px 12px', fontFamily:"'Outfit',sans-serif", fontSize:10, fontWeight:700, letterSpacing:'0.05em' }}>
                ⭐ POPULAIRE
              </div>
              <div className="label-sm" style={{ color:'var(--emerald)', marginBottom:14 }}>Paiement unique</div>
              <div style={{ display:'flex', alignItems:'baseline', gap:6, marginBottom:4 }}>
                <span style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:46, fontWeight:700, color:'var(--emerald)', lineHeight:1 }}>1 000</span>
                <span style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)', fontSize:14 }}>FCFA</span>
              </div>
              <div style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-light)', fontSize:13, marginBottom:24 }}>1 analyse complète · Sans abonnement</div>
              <ul style={{ listStyle:'none', padding:0, flex:1, marginBottom:24 }}>
                {PRICING.once.features.map((t,i) => (
                  <li key={i} style={{ display:'flex', gap:10, marginBottom:10, color:'var(--text-3)', fontSize:13, alignItems:'flex-start', fontFamily:"'Outfit',sans-serif" }}>
                    <span style={{ color:'var(--emerald)', fontWeight:700, flexShrink:0, marginTop:1 }}>✓</span>{t}
                  </li>
                ))}
              </ul>
              <a href={waPayLink(PACKS[0], '', '')} target="_blank" rel="noreferrer"
                style={{
                  display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                  padding:'14px', borderRadius:12,
                  fontFamily:"'Outfit',sans-serif", fontSize:14, fontWeight:600,
                  background:'var(--emerald)', color:'#F0FDF4', textDecoration:'none',
                  boxShadow:'0 4px 16px rgba(11,77,46,.3)',
                }}>
                <WaIcon size={15}/> Payer 1 000 FCFA — Wave
              </a>
            </div>

            {/* PRO 6 mois */}
            <div style={{
              padding:'30px 26px', display:'flex', flexDirection:'column',
              borderRadius:20, position:'relative', overflow:'hidden',
              background:'linear-gradient(160deg, #0F1D0D 0%, #142B10 100%)',
              boxShadow:'0 8px 40px rgba(15,29,13,.3)',
            }}>
              {/* Barre top or */}
              <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:'linear-gradient(to right, transparent, #C9A84C 20%, #E8C96A 50%, #B8860B 80%, transparent)' }}/>
              <div className="geo-gold" style={{ position:'absolute', inset:0, opacity:.5 }}/>
              <div style={{ position:'relative', zIndex:1, display:'flex', flexDirection:'column', flex:1 }}>
                <div style={{ position:'absolute', top:0, right:0, background:'rgba(139,105,20,.3)', border:'1px solid rgba(200,170,80,.3)', color:'rgba(200,170,80,.9)', borderRadius:100, padding:'3px 12px', fontFamily:"'Outfit',sans-serif", fontSize:10, fontWeight:700, letterSpacing:'0.05em' }}>
                  🏆 MEILLEURE VALEUR
                </div>
                <div style={{ fontFamily:"'Outfit',sans-serif", fontSize:11, fontWeight:600, color:'rgba(200,170,80,.7)', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:14 }}>Pro — 6 mois</div>
                <div style={{ display:'flex', alignItems:'baseline', gap:6, marginBottom:4 }}>
                  <span style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:46, fontWeight:700, lineHeight:1 }} className="gold-shimmer-text">5 000</span>
                  <span style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.5)', fontSize:14 }}>FCFA</span>
                </div>
                <div style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.4)', fontSize:13, marginBottom:8 }}>Illimité · 180 jours · Journal mensuel</div>
                <div style={{ background:'rgba(139,105,20,.15)', border:'1px solid rgba(139,105,20,.25)', borderRadius:8, padding:'7px 12px', marginBottom:20, display:'flex', alignItems:'center', gap:6, fontFamily:"'Outfit',sans-serif", fontSize:12, fontWeight:600, color:'rgba(200,170,80,.85)' }}>
                  <BookOpen size={13}/> + Journal mensuel des rêves inclus
                </div>
                <ul style={{ listStyle:'none', padding:0, flex:1, marginBottom:24 }}>
                  {PRICING.pro.features.map((t,i) => (
                    <li key={i} style={{ display:'flex', gap:10, marginBottom:10, color:'rgba(247,243,236,.7)', fontSize:13, alignItems:'flex-start', fontFamily:"'Outfit',sans-serif" }}>
                      <span style={{ color:'rgba(200,170,80,.8)', fontWeight:700, flexShrink:0, marginTop:1 }}>✓</span>{t}
                    </li>
                  ))}
                </ul>
                <a href={waPayLink(PACKS[1], '', '')} target="_blank" rel="noreferrer"
                  style={{
                    display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                    padding:'14px', borderRadius:12,
                    fontFamily:"'Outfit',sans-serif", fontSize:14, fontWeight:700,
                    background:'linear-gradient(135deg,#C9A84C,#E8C96A 40%,#B8860B)',
                    color:'#0F1D0D', textDecoration:'none',
                    boxShadow:'0 4px 20px rgba(139,105,20,.45)',
                    letterSpacing:'0.02em',
                  }}>
                  <WaIcon size={15}/> Payer 5 000 FCFA — Wave
                </a>
              </div>
            </div>
          </div>

          <p style={{ textAlign:'center', fontFamily:"'Outfit',sans-serif", color:'var(--text-light)', fontSize:12, marginTop:20 }}>
            💳 Paiement Wave · Confirmation sous 5 min · <em style={{ color:'var(--gold)' }}>In sha Allah</em>
          </p>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          TÉMOIGNAGES
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--bg-alt)', padding:'80px 20px' }}>
        <div style={{ maxWidth:960, margin:'0 auto', textAlign:'center' }}>
          <div className="label-sm" style={{ color:'var(--emerald)', marginBottom:12 }}>Témoignages</div>
          <h2 style={{ marginBottom:16 }}>+3 200 musulmans<br/>ont compris leurs rêves</h2>
          <div style={{ display:'flex', justifyContent:'center', marginBottom:40 }}>
            <ArabesqueOrnament/>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(270px,1fr))', gap:18 }}>
            {TESTIMONIALS.map((t,i) => (
              <div key={i} className="card-luxury" style={{ padding:'26px', textAlign:'left' }}>
                <div style={{ display:'flex', gap:3, marginBottom:14 }}>
                  {[0,1,2,3,4].map(j => <Star key={j} size={13} fill="var(--gold-bright)" stroke="none"/>)}
                </div>
                <p style={{ fontFamily:"'Cormorant Garamond',serif", color:'var(--text-3)', fontSize:'1.05rem', lineHeight:1.8, marginBottom:20, fontStyle:'italic' }}>
                  "{t.text}"
                </p>
                <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                  <img src={t.avatar} alt={t.name} style={{ width:44, height:44, borderRadius:'50%', objectFit:'cover', border:'2px solid var(--gold-soft)' }}/>
                  <div>
                    <div style={{ fontFamily:"'Outfit',sans-serif", fontWeight:700, color:'var(--text)', fontSize:14 }}>{t.name}</div>
                    <div style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)', fontSize:12 }}>{t.city} · Sénégal 🇸🇳</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          OUTILS ISLAMIQUES
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--card)', padding:'64px 20px' }}>
        <div style={{ maxWidth:920, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:36 }}>
            <div className="label-sm" style={{ color:'var(--gold)', marginBottom:12 }}>Outils islamiques</div>
            <h2>Horaires de prière &amp; Calendrier hijri</h2>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))', gap:20 }}>
            <PrayerWidget/>
            <IslamicCalendar/>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          FAQ
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--bg)', padding:'80px 20px' }}>
        <div style={{ maxWidth:680, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:44 }}>
            <div className="label-sm" style={{ color:'var(--emerald)', marginBottom:12 }}>FAQ</div>
            <h2>Vos questions,<br/>nos réponses</h2>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {FAQS.map((faq, i) => (
              <div key={i} className="card-luxury" style={{ overflow:'hidden' }}>
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', gap:16, padding:'18px 22px', background:'none', border:'none', cursor:'pointer', textAlign:'left' }}
                >
                  <span style={{ fontFamily:"'Cormorant Garamond',serif", fontWeight:600, color:'var(--text)', fontSize:16 }}>{faq.q}</span>
                  {openFaq === i
                    ? <ChevronUp size={16} style={{ color:'var(--gold)', flexShrink:0 }}/>
                    : <ChevronDown size={16} style={{ color:'var(--text-muted)', flexShrink:0 }}/>
                  }
                </button>
                {openFaq === i && (
                  <div style={{ padding:'0 22px 18px', fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)', fontSize:14, lineHeight:1.8 }}>
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          CTA FINAL
      ══════════════════════════════════════════════════════════ */}
      <section style={{ background:'var(--bg-hero)', padding:'88px 20px', textAlign:'center', position:'relative', overflow:'hidden' }}>
        <div className="geo" style={{ position:'absolute', inset:0, opacity:.5 }}/>
        <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width:500, height:500, borderRadius:'50%', background:'radial-gradient(ellipse, rgba(139,105,20,.1) 0%, transparent 70%)', pointerEvents:'none' }}/>

        <div style={{ maxWidth:660, margin:'0 auto', position:'relative', zIndex:1 }}>
          <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:'3rem', color:'rgba(200,170,80,.12)', marginBottom:8, direction:'rtl', lineHeight:1 }}>رُؤْيَا</div>

          <h2 style={{ color:'#F7F3EC', fontFamily:"'Cormorant Garamond',serif", fontSize:'clamp(2rem,5vw,3.2rem)', fontWeight:700, lineHeight:1.15, marginBottom:16 }}>
            Ce rêve que vous avez fait<br/>
            <span className="gold-shimmer-text">mérite une vraie réponse.</span>
          </h2>

          <div style={{ display:'flex', justifyContent:'center', marginBottom:28 }}>
            <ArabesqueOrnament color="rgba(200,170,80,.4)" size={20}/>
          </div>

          <p style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.55)', fontSize:'1rem', lineHeight:1.8, marginBottom:36 }}>
            Des milliers de musulmans ont déjà compris ce que leurs rêves leur disaient.<br/>
            La première interprétation est <strong style={{ color:'rgba(200,170,80,.8)' }}>100% gratuite</strong>. Sans carte. <em>In sha Allah.</em>
          </p>

          <Link to="/login" style={{
            display:'inline-flex', alignItems:'center', gap:10,
            fontFamily:"'Outfit',sans-serif",
            fontSize:17, fontWeight:700, padding:'18px 48px', borderRadius:14,
            background:'linear-gradient(135deg,#C9A84C 0%,#E8C96A 40%,#B8860B 100%)',
            color:'#0F1D0D', textDecoration:'none',
            boxShadow:'0 4px 28px rgba(139,105,20,.45)',
            letterSpacing:'0.02em',
          }}>
            🌙 Interpréter mon rêve maintenant
          </Link>

          <div style={{ marginTop:28, display:'flex', flexWrap:'wrap', justifyContent:'center', gap:20, fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.3)', fontSize:12 }}>
            <span><Shield size={12} style={{ display:'inline', verticalAlign:'middle', marginRight:4 }}/>Confidentiel</span>
            <span><Zap size={12} style={{ display:'inline', verticalAlign:'middle', marginRight:4 }}/>Immédiat</span>
            <span>🕌 Ibn Sirin</span>
            <span>🇸🇳 Experts sénégalais</span>
          </div>
        </div>
      </section>

    </div>
  )
}
