// ─── Interpret.jsx v21 ────────────────────────────────────────────
// ✅ P0  — Email obligatoire à l'étape 2 (avant résultat)
// ✅ P1  — Blur reveal inline + micro-testimonials dans ResultView
// ✅ P2  — Journal mensuel des rêves (voir ResultView)
// ✅ UX  — Temps validation : 5 min (plus 30 min)
// ✅ UX  — Phrase d'incitation émotionnelle

import React, { useState, useCallback, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { ChevronRight, ChevronLeft, Moon, AlertCircle, CheckCircle, Mail, Phone } from 'lucide-react'
import { EMOTIONS, TIMES, PACKS, waPayLink } from '../utils/constants.js'
import { analyzeDream } from '../utils/api.js'
import { genDreamId, saveDream } from '../utils/storage.js'
import { saveInterpretation, createPayment } from '../utils/airtable.js'
import { checkAccess, consumeAccess, loginOrRegister, freeRemainingThisMonth, FREE_MONTHLY_LIMIT } from '../utils/auth.js'
import { useAuth } from '../utils/AuthContext.jsx'
import ResultView from '../components/ResultView.jsx'

const WaIcon = ({ size=16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

function Paywall({ user }) {
  const dreamId = useRef(genDreamId()).current
  const handlePackClick = async (pack) => {
    try { if (user?.id) await createPayment(user.id, pack.price, user.email||'', dreamId) } catch {}
  }

  const STATS = [
    { val: '2 000+', label: 'rêves analysés' },
    { val: '4.9/5',  label: 'satisfaction' },
    { val: '< 5 min', label: 'délai validation' },
  ]

  return (
    <div style={{ padding: '28px 22px' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: 20 }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>🔒</div>
        <h2 style={{ fontFamily: "'Amiri',serif", fontSize: '1.6rem', fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>
          Vos 2 interprétations gratuites<br/>du mois sont épuisées
        </h2>
        <p style={{ color: 'var(--text-2)', fontSize: 13, fontStyle: 'italic', marginBottom: 0 }}>
          Ce rêve a un sens. Allah ne vous envoie pas de signes en vain.
        </p>
      </div>

      {/* Stats Omnisend-style */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 22 }}>
        {STATS.map((s, i) => (
          <div key={i} style={{ background: 'var(--bg)', borderRadius: 10, padding: '10px 6px', textAlign: 'center' }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: 'var(--text)' }}>{s.val}</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Grille des plans */}
      <div style={{ marginBottom: 18 }}>

        {/* Plan Free (désactivé) */}
        <div style={{ border: '1px solid var(--card-border)', borderRadius: 12, padding: '14px 16px', marginBottom: 10, opacity: 0.6, background: 'var(--bg)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text)' }}>Gratuit</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>2 interp./mois · Aperçu 40%</div>
            </div>
            <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>0 FCFA</div>
          </div>
          <div style={{ marginTop: 8, fontSize: 11, color: 'var(--text-muted)', textAlign: 'center' }}>
            ⏳ Disponible le 1er du mois prochain
          </div>
        </div>

        {/* Pack Once */}
        {PACKS.filter(p => !p.subscription).map(pack => (
          <a key={pack.id}
            href={waPayLink(pack, user?.email || '', dreamId)}
            target="_blank" rel="noreferrer"
            onClick={() => handlePackClick(pack)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 12, border: '2.5px solid var(--blue)', background: 'var(--blue-pale)', textDecoration: 'none', cursor: 'pointer', marginBottom: 10, position: 'relative' }}>
            <div style={{ position: 'absolute', top: -10, right: 12, background: 'var(--blue)', color: '#fff', borderRadius: 20, padding: '2px 10px', fontSize: 10, fontWeight: 700 }}>
              ⚡ ACCÈS IMMÉDIAT
            </div>
            <WaIcon size={18}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--blue-text)' }}>{pack.label}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Analyse 100% débloquée · Une fois</div>
            </div>
            <div style={{ fontFamily: "'Amiri',serif", fontSize: 18, fontWeight: 700, color: 'var(--blue)' }}>{pack.fcfa}</div>
          </a>
        ))}

        {/* Pack Pro */}
        {PACKS.filter(p => p.subscription).map(pack => (
          <a key={pack.id}
            href={waPayLink(pack, user?.email || '', dreamId)}
            target="_blank" rel="noreferrer"
            onClick={() => handlePackClick(pack)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 12, border: '2px solid var(--green)', background: 'var(--green-pale)', textDecoration: 'none', cursor: 'pointer', position: 'relative' }}>
            <div style={{ position: 'absolute', top: -10, left: 12, background: 'var(--green)', color: '#fff', borderRadius: 20, padding: '2px 10px', fontSize: 10, fontWeight: 700 }}>
              🏆 MEILLEURE VALEUR
            </div>
            <WaIcon size={18}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: '#0F6E56' }}>{pack.label}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Illimité · 6 mois · Journal mensuel</div>
              {pack.bonus && <div style={{ fontSize: 10, color: 'var(--gold)', fontWeight: 600, marginTop: 2 }}>🎁 {pack.bonus}</div>}
            </div>
            <div style={{ fontFamily: "'Amiri',serif", fontSize: 18, fontWeight: 700, color: 'var(--green)' }}>{pack.fcfa}</div>
          </a>
        ))}
      </div>

      {/* Comment ça marche */}
      <div style={{ padding: '12px 14px', background: 'var(--info-bg)', border: '1px solid var(--info-border)', borderRadius: 10, fontSize: 12, color: 'var(--info-text)' }}>
        <strong>Comment ça marche :</strong>
        <ol style={{ paddingLeft: 16, marginTop: 6, lineHeight: 1.9 }}>
          <li>Cliquez sur un pack → WhatsApp s'ouvre</li>
          <li>Envoyez votre preuve de paiement Wave</li>
          <li>Validation sous <strong>5 minutes</strong> · <em style={{ color: 'var(--gold)' }}>In sha Allah</em></li>
        </ol>
      </div>
    </div>
  )
}

export default function Interpret() {
  const { user, setUser, refresh } = useAuth()
  const [step, setStep]       = useState(1)
  const [form, setForm]       = useState({ text:'', email:'', phone:'', emotion:'', time:'' })
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)
  const [result, setResult]   = useState(null)
  const [dreamId, setDreamId] = useState(null)
  const [showPaywall, setShowPaywall] = useState(false)

  useEffect(() => {
    if (step === 6) return
    if (!user) return
    const access = checkAccess(user)
    setShowPaywall(!access.hasAccess)
  }, [user, step])

  useEffect(() => {
    if (user?.email && !form.email) setForm(f => ({ ...f, email: user.email }))
  }, [user])

  const patch = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const canGo = () => {
    if (step === 1) return form.text.trim().length >= 40
    if (step === 2) return form.email.includes('@') && form.email.includes('.')
    if (step === 3) return form.emotion !== ''
    if (step === 4) return form.time !== ''
    return true
  }

  const access = checkAccess(user)

  const handleEmailNext = async () => {
    const email = form.email.toLowerCase().trim()
    if (!email.includes('@') || !email.includes('.')) { setError('Email invalide.'); return }
    setError(null)
    if (!user) {
      try {
        const usr = await loginOrRegister(email, form.phone?.trim() || '')
        setUser(usr)
      } catch (e) { console.warn('loginOrRegister:', e.message) }
    }
    setStep(3)
  }

  const submit = useCallback(async () => {
    const freshAccess = checkAccess(user)
    if (!freshAccess.hasAccess) { setShowPaywall(true); return }
    setLoading(true); setError(null)
    try {
      const id  = genDreamId()
      const res = await analyzeDream({ text:form.text, emotion:form.emotion, time:form.time, name:user?.email }, false)
      setDreamId(id); setResult(res); setStep(6)
      consumeAccess(user).then(() => refresh()).catch(() => {})
      if (user?.id) saveInterpretation(user.id, form.text, res.text, user.email||'').catch(() => {})
      saveDream({ id:Date.now(), dreamId:id, date:new Date().toISOString(), ...form, result:res })
    } catch(e) {
      setError(e?.message ?? 'Une erreur est survenue. Vérifiez votre connexion.')
    } finally { setLoading(false) }
  }, [form, user, refresh])

  const restart = () => {
    setStep(1)
    setForm(f => ({ text:'', email:f.email, phone:f.phone, emotion:'', time:'' }))
    setResult(null); setError(null); setDreamId(null)
    if (user) setShowPaywall(!checkAccess(user).hasAccess)
  }

  const freeLeft = freeRemainingThisMonth(user?.id)

  const AccessBadge = () => {
    if (!user) return null
    if (access.reason === 'subscription') return <div className="badge-green" style={{display:'inline-flex',marginBottom:12}}>♾️ Pro actif — illimité 6 mois</div>
    if (access.reason === 'credits')      return <div className="badge-blue"  style={{display:'inline-flex',marginBottom:12}}>💎 {user.credits} crédit{user.credits>1?'s':''} disponible{user.credits>1?'s':''}</div>
    if (access.reason === 'free')         return (
      <div className="badge-green" style={{display:'inline-flex',alignItems:'center',gap:6,marginBottom:12}}>
        🎁 {freeLeft}/{FREE_MONTHLY_LIMIT} interprétations gratuites ce mois
      </div>
    )
    return null
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg)', padding:'80px 16px 64px' }}>
      <div style={{ maxWidth:560, margin:'0 auto' }}>

        <div style={{ textAlign:'center', marginBottom:24 }}>
          <div className="label-sm mb-1" style={{ color:'var(--green)' }}>Tafsir al-Ahlam</div>
          <h1 style={{ fontFamily:"'Amiri',serif", fontSize:'clamp(1.8rem,5vw,2.5rem)', fontWeight:700, color:'var(--text)', marginBottom:4 }}>Interpréter mon rêve</h1>
          <p style={{ color:'var(--text-muted)', fontSize:13 }}>Sheikh Momar · Ibn Sirin · Al-Nabulsi</p>
          {user && !showPaywall && <div style={{ marginTop:8 }}><AccessBadge /></div>}
        </div>

        {showPaywall && (
          <div className="card" style={{ overflow:'hidden' }}>
            <Paywall user={user} />
          </div>
        )}

        {!showPaywall && (
          <>
            {step <= 5 && (
              <div style={{ display:'flex', justifyContent:'center', gap:6, marginBottom:24 }}>
                {[1,2,3,4,5].map(n => <div key={n} className={`dot${n<step?' done':n===step?' active':''}`}/>)}
              </div>
            )}

            {/* Étape 1 — Description */}
            {step === 1 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 1 / 5</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:16}}>Décrivez votre rêve</h2>
                <div style={{position:'relative',marginBottom:8}}>
                  <textarea value={form.text} onChange={e=>patch('text',e.target.value)}
                    className="field" style={{minHeight:180,resize:'none'}}
                    placeholder="J'ai rêvé que je me trouvais dans une grande mosquée blanche…"
                    maxLength={3000} autoFocus/>
                  <span style={{position:'absolute',bottom:12,right:14,fontSize:11,color:'var(--text-muted)'}}>{form.text.length}/3000</span>
                </div>
                {form.text.length > 0 && form.text.length < 40 && (
                  <p style={{fontSize:12,color:'var(--gold)',marginBottom:10}}>Minimum 40 caractères pour une analyse précise</p>
                )}
                <button onClick={()=>setStep(2)} disabled={!canGo()} className="btn btn-primary" style={{width:'100%',padding:'14px',fontSize:15,borderRadius:12}}>
                  Continuer <ChevronRight size={18}/>
                </button>
              </div>
            )}

            {/* Étape 2 — Email (P0) */}
            {step === 2 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 2 / 5</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:6}}>Où envoyer votre interprétation ?</h2>
                <p style={{color:'var(--text-muted)',fontSize:13,marginBottom:18,lineHeight:1.6}}>
                  Votre analyse sera sauvegardée dans votre espace personnel.<br/>
                  <strong style={{color:'var(--green)'}}>1 interprétation gratuite</strong> offerte à l'inscription.
                </p>
                <div style={{marginBottom:12}}>
                  <label style={{fontSize:13,fontWeight:600,color:'var(--text-2)',display:'block',marginBottom:5}}>
                    Email <span style={{color:'var(--error-text)'}}>*</span>
                  </label>
                  <div style={{position:'relative'}}>
                    <Mail size={14} style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',color:'var(--text-muted)',pointerEvents:'none'}}/>
                    <input type="email" value={form.email}
                      onChange={e => { patch('email', e.target.value); setError(null) }}
                      onKeyDown={e => e.key==='Enter' && handleEmailNext()}
                      className="field" style={{paddingLeft:34}}
                      placeholder="votre@email.com" autoFocus
                      disabled={!!user}
                    />
                  </div>
                  {user && <p style={{fontSize:11,color:'var(--green)',marginTop:4}}>✓ Connecté · {user.email}</p>}
                </div>
                {!user && (
                  <div style={{marginBottom:18}}>
                    <label style={{fontSize:13,fontWeight:600,color:'var(--text-2)',display:'block',marginBottom:5}}>
                      WhatsApp <span style={{fontWeight:400,color:'var(--text-muted)'}}>(optionnel)</span>
                    </label>
                    <div style={{position:'relative'}}>
                      <Phone size={14} style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',color:'var(--text-muted)',pointerEvents:'none'}}/>
                      <input type="tel" value={form.phone}
                        onChange={e=>patch('phone',e.target.value)}
                        className="field" style={{paddingLeft:34}}
                        placeholder="+221 76 956 57 48"/>
                    </div>
                  </div>
                )}
                {error && (
                  <div style={{display:'flex',alignItems:'flex-start',gap:8,padding:'10px 12px',background:'var(--error-bg)',border:'1px solid var(--error-border)',borderRadius:10,marginBottom:14,fontSize:12,color:'var(--error-text)'}}>
                    <AlertCircle size={14} style={{flexShrink:0,marginTop:1}}/><span>{error}</span>
                  </div>
                )}
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(1)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={handleEmailNext} disabled={!canGo()} className="btn btn-primary" style={{flex:1,padding:'12px',borderRadius:12}}>
                    Continuer <ChevronRight size={18}/>
                  </button>
                </div>
                <p style={{textAlign:'center',fontSize:11,color:'var(--text-muted)',marginTop:12}}>🔒 Données confidentielles · Aucune carte requise</p>
              </div>
            )}

            {/* Étape 3 — Émotion */}
            {step === 3 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 3 / 5</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:6}}>Émotion ressentie</h2>
                <p style={{color:'var(--text-muted)',fontSize:13,marginBottom:18}}>Ibn Sirin accordait une importance capitale à l'émotion.</p>
                <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:24}}>
                  {EMOTIONS.map(e => (
                    <button key={e.label} onClick={()=>patch('emotion',e.label)} className={`emo-btn${form.emotion===e.label?' on':''}`}>
                      <div style={{fontSize:22,marginBottom:4}}>{e.emoji}</div>
                      <div style={{fontSize:11}}>{e.label}</div>
                    </button>
                  ))}
                </div>
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(2)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={()=>setStep(4)} disabled={!canGo()} className="btn btn-primary" style={{flex:1,padding:'12px',borderRadius:12}}>Continuer <ChevronRight size={18}/></button>
                </div>
              </div>
            )}

            {/* Étape 4 — Moment */}
            {step === 4 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 4 / 5</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:8}}>Moment du rêve</h2>
                <div style={{padding:'12px 16px',background:'var(--gold-pale)',border:'1px solid #FDE68A',borderRadius:10,marginBottom:18,fontSize:13,color:'var(--text-2)'}}>
                  ﷺ <em style={{color:'var(--gold)'}}>"Les rêves les plus véridiques surviennent avant Fajr."</em> — Muslim
                </div>
                <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:24}}>
                  {TIMES.map(t => (
                    <button key={t.v} onClick={()=>patch('time',t.v)}
                      style={{display:'flex',alignItems:'center',gap:12,padding:'12px 16px',borderRadius:12,border:'1.5px solid',textAlign:'left',cursor:'pointer',background:form.time===t.v?'var(--green-pale)':'#fff',borderColor:form.time===t.v?'var(--green)':'var(--card-border)',transition:'all .18s'}}>
                      <span style={{fontSize:18}}>{t.star?'⭐':'🌑'}</span>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:600,fontSize:14,color:form.time===t.v?'var(--green)':'var(--text)',marginBottom:2}}>{t.label}</div>
                        <div style={{fontSize:12,color:'var(--text-muted)'}}>{t.hint}{t.star?' — Heure la plus bénie':''}</div>
                      </div>
                      {form.time===t.v && <CheckCircle size={17} style={{color:'var(--green)'}}/>}
                    </button>
                  ))}
                </div>
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(3)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={()=>setStep(5)} disabled={!canGo()} className="btn btn-primary" style={{flex:1,padding:'12px',borderRadius:12}}>Continuer <ChevronRight size={18}/></button>
                </div>
              </div>
            )}

            {/* Étape 5 — Confirmation */}
            {step === 5 && (
              <div className="card p-6 up">
                <p className="label-sm mb-1" style={{color:'var(--blue)'}}>Étape 5 / 5</p>
                <h2 style={{fontFamily:"'Amiri',serif",fontSize:'1.4rem',fontWeight:700,color:'var(--text)',marginBottom:16}}>Confirmation</h2>
                <div style={{background:'var(--bg)',border:'1.5px solid var(--card-border)',borderRadius:12,padding:16,marginBottom:14}}>
                  <p style={{fontSize:13,color:'var(--text-3)',marginBottom:6}}><strong>Email :</strong> {form.email || user?.email}</p>
                  <p style={{fontSize:13,color:'var(--text-2)',marginBottom:6}}><strong>Rêve :</strong> <em>"{form.text.slice(0,80)}{form.text.length>80?'…':''}"</em></p>
                  <p style={{fontSize:13,color:'var(--text-2)'}}><strong>Émotion :</strong> {form.emotion} · <strong>Moment :</strong> {TIMES.find(t=>t.v===form.time)?.label}</p>
                </div>
                <div style={{padding:'12px 14px',background:'var(--green-pale)',border:'1px solid #A7F3D0',borderRadius:10,marginBottom:14,fontSize:13,color:'var(--text-2)'}}>
                  🎁 <strong>Analyse gratuite</strong> — Sheikh Momar · Ibn Sirin & Al-Nabulsi · 420+ mots
                </div>
                {error && (
                  <div style={{display:'flex',alignItems:'flex-start',gap:8,padding:'10px 14px',background:'var(--error-bg)',border:'1px solid var(--error-border)',borderRadius:10,marginBottom:14,fontSize:13,color:'var(--error-text)'}}>
                    <AlertCircle size={15} style={{flexShrink:0,marginTop:1}}/>{error}
                  </div>
                )}
                <div style={{display:'flex',gap:10}}>
                  <button onClick={()=>setStep(4)} className="btn btn-outline" style={{padding:'12px 16px',borderRadius:12}}><ChevronLeft size={18}/></button>
                  <button onClick={submit} disabled={loading} className="btn btn-primary" style={{flex:1,padding:'14px',fontSize:15,borderRadius:12}}>
                    {loading ? <><span className="spin" style={{width:18,height:18,border:'2px solid rgba(255,255,255,.3)',borderTopColor:'#fff'}}/> Analyse…</> : <><Moon size={18}/> Obtenir l'interprétation</>}
                  </button>
                </div>
              </div>
            )}

            {/* Étape 6 — Résultat */}
            {step === 6 && result && (
              <div className="up">
                <ResultView result={result} form={form} dreamId={dreamId} onRestart={restart} user={user}/>
              </div>
            )}
          </>
        )}

        {loading && (
          <div style={{position:'fixed',inset:0,zIndex:50,display:'flex',alignItems:'center',justifyContent:'center',padding:16,background:'rgba(255,255,255,.92)',backdropFilter:'blur(4px)'}}>
            <div className="card" style={{padding:40,textAlign:'center',maxWidth:320,width:'100%'}}>
              <div className="float" style={{fontSize:52,marginBottom:16}}>🌙</div>
              <div style={{fontFamily:"'Amiri',serif",fontSize:'1.3rem',fontWeight:700,color:'var(--text)',marginBottom:8}}>Consultation en cours…</div>
              <p style={{color:'var(--text-muted)',fontSize:13,marginBottom:20}}>Sheikh Momar analyse selon Ibn Sirin et Al-Nabulsi</p>
              <div style={{display:'flex',justifyContent:'center'}}><div className="spin"/></div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
