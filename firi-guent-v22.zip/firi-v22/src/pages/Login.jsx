// ─── Login.jsx v21 — Luxe Arabesque ──────────────────────────────
import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Mail, Phone, ArrowRight, Loader, AlertCircle, CheckCircle } from 'lucide-react'
import { loginOrRegister } from '../utils/auth.js'
import { useAuth } from '../utils/AuthContext.jsx'

export default function Login() {
  const [email,   setEmail]   = useState('')
  const [phone,   setPhone]   = useState('')
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const [step,    setStep]    = useState('form')
  const { setUser, user }     = useAuth()
  const navigate              = useNavigate()

  useEffect(() => { if (user) navigate('/interpreter', { replace: true }) }, [user])

  const isValid = email.includes('@') && email.includes('.')

  const submit = async () => {
    if (!isValid) { setError('Entrez un email valide (ex: nom@gmail.com)'); return }
    setLoading(true); setError(''); setStep('loading')
    try {
      const usr = await loginOrRegister(email.trim().toLowerCase(), phone.trim())
      setUser(usr); setStep('done')
      setTimeout(() => navigate('/interpreter'), 800)
    } catch (e) {
      setStep('form')
      const msg = e.message || ''
      if (msg.includes('Connexion impossible') || msg.includes('fetch')) {
        setError('Impossible de joindre le serveur. Vérifiez votre connexion.')
      } else if (msg.includes('401') || msg.includes('AUTHENTICATION')) {
        setError('Token invalide. Contactez le support.')
      } else {
        setError(msg || 'Une erreur est survenue. Réessayez.')
      }
    } finally { setLoading(false) }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-hero)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20,
      position: 'relative', overflow: 'hidden',
    }}>

      {/* Motif géométrique fond */}
      <div className="geo" style={{ position:'absolute', inset:0, opacity:.4 }}/>

      {/* Lueur dorée */}
      <div style={{
        position:'absolute', top:'20%', left:'50%', transform:'translateX(-50%)',
        width:400, height:400, borderRadius:'50%',
        background:'radial-gradient(ellipse, rgba(139,105,20,.15) 0%, transparent 70%)',
        pointerEvents:'none',
      }}/>

      <div style={{ width:'100%', maxWidth:440, position:'relative', zIndex:1 }}>

        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:36 }}>
          <div className="float" style={{ fontSize:54, marginBottom:12, filter:'drop-shadow(0 0 20px rgba(139,105,20,.35))' }}>🌙</div>
          <h1 style={{
            fontFamily:"'Cormorant Garamond',serif",
            fontSize:'2.4rem', fontWeight:700, color:'#F7F3EC',
            marginBottom:4, letterSpacing:'-0.02em',
          }}>
            Firi Guent
          </h1>
          <div style={{ fontFamily:"'Scheherazade New',serif", fontSize:'1.2rem', color:'rgba(200,170,80,.8)', direction:'rtl', marginBottom:4 }}>
            تفسير الأحلام الإسلامي
          </div>
          {/* Ligne ornementale */}
          <div style={{ display:'flex', alignItems:'center', gap:12, justifyContent:'center', marginTop:12, opacity:.5 }}>
            <div style={{ width:40, height:1, background:'linear-gradient(to right, transparent, rgba(200,170,80,.6))' }}/>
            <span style={{ fontFamily:"'Scheherazade New',serif", fontSize:16, color:'rgba(200,170,80,.7)' }}>✦</span>
            <div style={{ width:40, height:1, background:'linear-gradient(to left, transparent, rgba(200,170,80,.6))' }}/>
          </div>
        </div>

        {/* Card */}
        <div style={{
          background: 'rgba(253,250,245,.97)',
          borderRadius: 24,
          padding: '32px 28px',
          boxShadow: '0 24px 80px rgba(0,0,0,.35), 0 0 0 1px rgba(139,105,20,.2)',
          backdropFilter: 'blur(20px)',
          position:'relative', overflow:'hidden',
        }}>
          {/* Barre dorée top */}
          <div style={{
            position:'absolute', top:0, left:0, right:0, height:2,
            background:'linear-gradient(to right, transparent, #C9A84C 20%, #E8C96A 50%, #B8860B 80%, transparent)',
            opacity:.9,
          }}/>

          {step === 'done' ? (
            <div style={{ textAlign:'center', padding:'20px 0' }}>
              <div style={{
                width:64, height:64, borderRadius:'50%',
                background:'var(--emerald-pale)', border:'2px solid var(--emerald-soft)',
                display:'flex', alignItems:'center', justifyContent:'center',
                margin:'0 auto 16px',
              }}>
                <CheckCircle size={32} style={{ color:'var(--emerald)' }}/>
              </div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:'1.4rem', fontWeight:700, color:'var(--text)', marginBottom:6 }}>
                Bienvenue ! 🤲
              </div>
              <p style={{ color:'var(--text-muted)', fontSize:14, fontFamily:"'Outfit',sans-serif" }}>
                Redirection en cours…
              </p>
            </div>
          ) : (
            <>
              <h2 style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:'1.5rem', fontWeight:700, color:'var(--text)', marginBottom:6, textAlign:'center' }}>
                Connexion / Inscription
              </h2>
              <p style={{ fontFamily:"'Outfit',sans-serif", color:'var(--text-muted)', fontSize:13, textAlign:'center', marginBottom:24, lineHeight:1.6 }}>
                Entrez votre email pour accéder à votre espace.<br/>
                <strong style={{ color:'var(--emerald)' }}>2 interprétations gratuites</strong> offertes chaque mois.
              </p>

              {/* Email */}
              <div style={{ marginBottom:14 }}>
                <label style={{ fontFamily:"'Outfit',sans-serif", fontSize:12, fontWeight:600, color:'var(--text-muted)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.08em' }}>
                  Email *
                </label>
                <div style={{ position:'relative' }}>
                  <Mail size={15} style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', color:'var(--text-light)', pointerEvents:'none' }}/>
                  <input
                    type="email" value={email}
                    onChange={e => { setEmail(e.target.value); setError('') }}
                    onKeyDown={e => e.key === 'Enter' && submit()}
                    className="field" style={{ paddingLeft:42, borderRadius:12, fontFamily:"'Outfit',sans-serif" }}
                    placeholder="votre@email.com"
                    autoFocus disabled={loading}
                  />
                </div>
              </div>

              {/* WhatsApp */}
              <div style={{ marginBottom:22 }}>
                <label style={{ fontFamily:"'Outfit',sans-serif", fontSize:12, fontWeight:600, color:'var(--text-muted)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.08em' }}>
                  WhatsApp <span style={{ fontWeight:400, color:'var(--text-light)', textTransform:'none', letterSpacing:0 }}>(optionnel)</span>
                </label>
                <div style={{ position:'relative' }}>
                  <Phone size={15} style={{ position:'absolute', left:14, top:'50%', transform:'translateY(-50%)', color:'var(--text-light)', pointerEvents:'none' }}/>
                  <input
                    type="tel" value={phone}
                    onChange={e => setPhone(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && submit()}
                    className="field" style={{ paddingLeft:42, borderRadius:12, fontFamily:"'Outfit',sans-serif" }}
                    placeholder="+221 76 956 57 48"
                    disabled={loading}
                  />
                </div>
              </div>

              {error && (
                <div style={{ display:'flex', alignItems:'flex-start', gap:8, padding:'10px 14px', background:'var(--error-bg)', border:'1px solid var(--error-border)', borderRadius:12, marginBottom:16, fontFamily:"'Outfit',sans-serif", fontSize:13, color:'var(--error-text)', lineHeight:1.5 }}>
                  <AlertCircle size={15} style={{ flexShrink:0, marginTop:1 }}/><span>{error}</span>
                </div>
              )}

              <button
                onClick={submit}
                disabled={loading || !isValid}
                className="btn btn-primary"
                style={{ width:'100%', padding:'15px', fontSize:15, borderRadius:14, fontFamily:"'Outfit',sans-serif", letterSpacing:'0.02em' }}
              >
                {loading
                  ? <><Loader size={17} style={{ animation:'animate-spin 1s linear infinite' }}/> Connexion…</>
                  : <>Accéder à Firi Guent <ArrowRight size={17}/></>
                }
              </button>

              {/* Ornement séparateur */}
              <div style={{ margin:'20px 0 16px', display:'flex', alignItems:'center', gap:12 }}>
                <div style={{ flex:1, height:1, background:'var(--card-border)' }}/>
                <span style={{ fontFamily:"'Scheherazade New',serif", fontSize:14, color:'var(--gold)', opacity:.6 }}>✦</span>
                <div style={{ flex:1, height:1, background:'var(--card-border)' }}/>
              </div>

              <p style={{ textAlign:'center', fontFamily:"'Outfit',sans-serif", fontSize:11, color:'var(--text-light)', lineHeight:1.6 }}>
                🔒 Données confidentielles · Aucune carte requise<br/>
                Compte créé automatiquement à la première connexion
              </p>
            </>
          )}
        </div>

        <div style={{ textAlign:'center', marginTop:20 }}>
          <Link to="/" style={{ fontFamily:"'Outfit',sans-serif", color:'rgba(247,243,236,.4)', fontSize:12, textDecoration:'none', transition:'color .2s' }}>
            ← Retour à l'accueil
          </Link>
        </div>
      </div>
    </div>
  )
}
