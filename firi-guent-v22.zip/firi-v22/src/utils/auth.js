// ─── auth.js v22 ──────────────────────────────────────────────────
// BUGS CORRIGÉS :
// 1. CRITIQUE : free_monthly_count + free_month_key gérés 100% en localStorage
//    → plus aucun envoi de ces champs vers Airtable → UNKNOWN_FIELD disparu
// 2. buildSession() ne lit plus free_monthly_count depuis Airtable (inexistant)
//    → lit uniquement depuis localStorage
// 3. consumeAccess() : n'écrit plus free_monthly_count dans Airtable
//    → garde uniquement free_used (boolean) pour compat Admin panel
//
// LOGIQUE ACCÈS v22 :
//   subscription  → illimité (plan + subscription_end dans Airtable)
//   one_time      → credits (number dans Airtable)
//   free          → 2 interp/mois comptées en localStorage (pas Airtable)

import { getUserByEmail, createUser, updateUser } from './airtable.js'

const SESSION_KEY       = 'fg14_session'
const FREE_COUNTER_KEY  = (userId) => `fg_free_${userId}`  // localStorage
export const FREE_MONTHLY_LIMIT = 2

// ─── Clé du mois courant ─────────────────────────────────────────
function currentMonthKey() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

// ─── Compteur mensuel gratuit (localStorage) ──────────────────────
function getFreeCounter(userId) {
  try {
    const raw = localStorage.getItem(FREE_COUNTER_KEY(userId))
    if (!raw) return { count: 0, month: '' }
    return JSON.parse(raw)
  } catch { return { count: 0, month: '' } }
}

function setFreeCounter(userId, count, month) {
  try {
    localStorage.setItem(FREE_COUNTER_KEY(userId), JSON.stringify({ count, month }))
  } catch {}
}

export function freeRemainingThisMonth(userId) {
  if (!userId) return 0
  const { count, month } = getFreeCounter(userId)
  if (month !== currentMonthKey()) return FREE_MONTHLY_LIMIT  // nouveau mois → reset
  return Math.max(0, FREE_MONTHLY_LIMIT - count)
}

// ─── Session helpers ──────────────────────────────────────────────
export function getSession() {
  try   { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null') }
  catch { return null }
}
export function setSession(user) {
  try { localStorage.setItem(SESSION_KEY, JSON.stringify(user)) } catch {}
}
export function clearSession() {
  try { localStorage.removeItem(SESSION_KEY) } catch {}
}

// ─── Build session depuis un record Airtable ─────────────────────
function buildSession(record) {
  const f     = record?.fields ?? {}
  const phone = Array.isArray(f.phone) ? f.phone[0] : (f.phone || '')
  return {
    id:               record.id,
    email:            f.email            || '',
    phone,
    plan:             f.plan             || 'free',
    credits:          Number(f.credits   || 0),
    subscription_end: f.subscription_end || null,
    free_used:        f.free_used        ?? false,
    // NOTE : free_monthly_count n'est PAS lu depuis Airtable (champ inexistant)
    // Il est calculé à la volée depuis localStorage via freeRemainingThisMonth()
  }
}

// ─── Login / Register ─────────────────────────────────────────────
export async function loginOrRegister(email, phone = '') {
  const e = email.toLowerCase().trim()
  if (!e || !e.includes('@')) throw new Error('Email invalide.')

  let record = await getUserByEmail(e)
  if (!record) {
    record = await createUser(e, phone)
  } else if (phone && !record.fields?.phone) {
    try { await updateUser(record.id, { phone }) } catch {}
  }

  const session = buildSession(record)
  setSession(session)
  return session
}

// ─── Refresh depuis Airtable ──────────────────────────────────────
export async function refreshSession() {
  const session = getSession()
  if (!session?.email) return null
  try {
    const fresh = await getUserByEmail(session.email)
    if (!fresh) { clearSession(); return null }
    const updated = buildSession(fresh)
    setSession(updated)
    return updated
  } catch {
    return session  // réseau KO → cache
  }
}

// ─── Contrôle d'accès ─────────────────────────────────────────────
export function checkAccess(user) {
  if (!user) return { hasAccess: false, reason: 'not_logged_in' }

  // Abonnement actif ?
  if (user.plan === 'subscription' && user.subscription_end) {
    const end = new Date(user.subscription_end)
    if (end > new Date()) return { hasAccess: true, reason: 'subscription' }
    // Expiré
    const updated = { ...user, plan: 'free', subscription_end: null }
    setSession(updated)
  }

  // Crédits paiement unique ?
  if (Number(user.credits) > 0) return { hasAccess: true, reason: 'credits' }

  // Free mensuel (localStorage) ?
  const remaining = freeRemainingThisMonth(user.id)
  if (remaining > 0) return { hasAccess: true, reason: 'free', remaining }

  return { hasAccess: false, reason: 'no_access' }
}

// ─── Consommer 1 accès ────────────────────────────────────────────
export async function consumeAccess(user) {
  if (!user?.id) return user
  if (user.plan === 'subscription') return user  // illimité

  // Décrémenter un crédit payant
  if (Number(user.credits) > 0) {
    const newCredits = Number(user.credits) - 1
    try { await updateUser(user.id, { credits: newCredits }) } catch {}
    const updated = { ...user, credits: newCredits }
    setSession(updated)
    return updated
  }

  // Consommer une interp gratuite mensuelle (localStorage uniquement)
  const mk      = currentMonthKey()
  const counter = getFreeCounter(user.id)
  const newCount = counter.month === mk ? counter.count + 1 : 1
  setFreeCounter(user.id, newCount, mk)

  // Mettre à jour free_used dans Airtable (champ existant, pour l'Admin)
  // On le met à true dès la 1ère utilisation
  if (!user.free_used) {
    try { await updateUser(user.id, { free_used: true }) } catch {}
  }

  const updated = { ...user, free_used: true }
  setSession(updated)
  return updated
}
