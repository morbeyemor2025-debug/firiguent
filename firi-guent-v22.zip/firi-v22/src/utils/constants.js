// ─── constants.js v20 ─────────────────────────────────────────────
// PLANS :
//   Free    → 0 FCFA · analyse tronquée 40% · 2 fois/mois
//   Once    → 1 000 FCFA · 100% débloqué · 1 interprétation
//   Pro     → 5 000 FCFA · illimité + journal mensuel · 6 mois (180 j)

const WA_NUM = '221769565748'
export const WA_BASE = `https://wa.me/${WA_NUM}`

// ─── Endpoints API sécurisés ──────────────────────────────────────
export const API_BASE          = import.meta.env.VITE_API_BASE || ''
export const ANALYZE_ENDPOINT  = `${API_BASE}/.netlify/functions/analyze`
export const AIRTABLE_ENDPOINT = `${API_BASE}/.netlify/functions/airtable-proxy`

// ─── Admin ────────────────────────────────────────────────────────
export const ADMIN_PASSWORD = 'firi2026'

// ─── Limites plan Free ────────────────────────────────────────────
export const FREE_MONTHLY_LIMIT = 2        // 2 interprétations gratuites/mois
export const FREE_TRUNCATE_PCT  = 40       // 40% du texte généré

// ─── Pricing ─────────────────────────────────────────────────────
export const PRICE_DISPLAY = '1 000 FCFA'
export const PRICE_FCFA    = 1000

export const PACKS = [
  {
    id: 'once',
    credits: 1,
    price: 1000,
    label: '1 interprétation complète',
    fcfa: '1 000 FCFA',
    popular: true,
    bonus: '',
    subscription: false,
    highlight: 'Accès immédiat · Une seule fois',
  },
  {
    id: 'pro',
    credits: 9999,
    price: 5000,
    label: 'Pro — 6 mois illimités',
    fcfa: '5 000 FCFA',
    popular: false,
    bonus: '+ Journal mensuel des rêves',
    subscription: true,
    highlight: '180 jours · Illimité · Journal mensuel',
  },
]

export const PRICING = {
  free: {
    id: 'free',
    label: 'Découverte',
    price: 0,
    fcfa: 'Gratuit',
    credits: 0,
    sub: false,
    features: [
      '2 interprétations gratuites / mois',
      'Aperçu à 40% du texte complet',
      'Symbole principal identifié',
      'Référence Ibn Sirin / Al-Nabulsi',
    ],
    missing: [
      'Analyse complète (60% cachés)',
      'Symboles secondaires',
      'Hadiths Bukhari/Muslim',
      "Cas des Compagnons ﷺ",
      "Du'a arabe complet",
      'Journal mensuel des rêves',
    ],
    cta: 'Commencer gratuitement',
  },
  once: {
    id: 'once',
    label: 'Paiement unique',
    price: 1000,
    fcfa: '1 000 FCFA',
    credits: 1,
    sub: false,
    popular: true,
    features: [
      '1 interprétation complète à 100%',
      'Tous les symboles analysés',
      'Hadiths Bukhari/Muslim cités',
      "Cas des Compagnons ﷺ",
      "Du'a arabe + phonétique + traduction",
      'Consultation experts sénégalais',
    ],
    missing: ['Journal mensuel des rêves'],
    cta: 'Payer 1 000 FCFA — Wave',
  },
  pro: {
    id: 'pro',
    label: 'Pro — 6 mois',
    price: 5000,
    fcfa: '5 000 FCFA',
    credits: 9999,
    sub: true,
    features: [
      'Interprétations ILLIMITÉES — 6 mois',
      'Tout du paiement unique',
      '📔 Journal mensuel des rêves',
      'Analyse psycho-spirituelle mensuelle',
      'Priorité de réponse',
      'Consultation Istikhar offerte',
      'Guidance spirituelle continue',
    ],
    missing: [],
    cta: 'Payer 5 000 FCFA — Wave',
  },
}

// ─── WhatsApp links ───────────────────────────────────────────────
export function waPayLink(pack, userEmail, dreamId) {
  const packLabel = pack?.label || 'Firi Guent'
  const packPrix  = pack?.fcfa  || '—'
  const ref       = dreamId     || '—'
  const email     = userEmail   || '—'
  const msg = [
    'Assalamu alaikum Firi Guent 🌙',
    '',
    'Je viens de payer pour Firi Guent. Voici ma preuve de paiement.',
    '',
    `Pack : ${packLabel} — ${packPrix}`,
    `Email : ${email}`,
    `Ref : ${ref}`,
    '',
    'In sha Allah. 🤲',
  ].join('\n')
  return `${WA_BASE}?text=${encodeURIComponent(msg)}`
}

export function waExpertLink(name) {
  const who = name ? `\nNom : ${name}` : ''
  const msg = `Assalamu alaikum,\n\nJe souhaite consulter un expert en interpretation islamique des reves.${who}\n\nBaraka Allahu fikoum.`
  return `${WA_BASE}?text=${encodeURIComponent(msg)}`
}

export function waDefaultLink() {
  return `${WA_BASE}?text=${encodeURIComponent('Bonjour, je viens de payer pour Firi Guent. Voici ma preuve de paiement.')}`
}

export function waNotFoundLink(keyword) {
  const kw  = keyword || 'mon reve'
  const msg = `Assalamu alaikum Firi Guent\n\nJe n'ai pas trouve l'interpretation de mon reve : "${kw}"\nPouvez-vous m'aider ? In sha Allah.`
  return `${WA_BASE}?text=${encodeURIComponent(msg)}`
}

export function waUnlockLink(dreamId, userEmail) {
  const ref   = dreamId   || 'N/A'
  const email = userEmail || '—'
  const msg = `Assalamu alaikum Firi Guent\n\nJ'ai paye Wave.\nReference : ${ref}\nEmail : ${email}\nMerci de confirmer. In sha Allah.`
  return `${WA_BASE}?text=${encodeURIComponent(msg)}`
}

// ─── Form options ─────────────────────────────────────────────────
export const EMOTIONS = [
  { emoji:'😨', label:'Peur'        },
  { emoji:'😌', label:'Sérénité'    },
  { emoji:'😢', label:'Tristesse'   },
  { emoji:'😊', label:'Joie'        },
  { emoji:'😰', label:'Angoisse'    },
  { emoji:'😮', label:'Surprise'    },
  { emoji:'🤔', label:'Confusion'   },
  { emoji:'🙏', label:'Spiritualité'},
]

export const TIMES = [
  { v:'avant_fajr',    label:'Avant Fajr',    hint:'03h–05h', star:true  },
  { v:'apres_fajr',    label:'Après Fajr',    hint:'05h–08h', star:true  },
  { v:'nuit_profonde', label:'Nuit profonde', hint:'00h–03h', star:false },
  { v:'journee',       label:'Journée',       hint:'08h–17h', star:false },
  { v:'soir',          label:'Soir',          hint:'17h–00h', star:false },
]

export const ISLAMIC_EVENTS = [
  { name:'Aïd el-Fitr 2025',  hijri:'1 Chawwal 1446',     gregorian:'30 mars 2025',  icon:'🌙' },
  { name:'Aïd el-Adha 2025',  hijri:'10 Dhul Hijja 1446', gregorian:'6 juin 2025',   icon:'🐑' },
  { name:'Nouvel An 1447',     hijri:'1 Muharram 1447',    gregorian:'27 juin 2025',  icon:'🎉' },
  { name:'Achoura 1447',       hijri:'10 Muharram 1447',   gregorian:'6 juil. 2025',  icon:'🤲' },
  { name:'Mawlid an-Nabawi',   hijri:'12 Rabi I 1447',     gregorian:'4 sept. 2025',  icon:'💚' },
  { name:'Ramadan 2026',       hijri:'1 Ramadan 1447',     gregorian:'17 fév. 2026',  icon:'☪️'  },
  { name:'Aïd el-Fitr 2026',  hijri:'1 Chawwal 1447',     gregorian:'19 mars 2026',  icon:'🌙' },
  { name:'Aïd el-Adha 2026',  hijri:'10 Dhul Hijja 1447', gregorian:'27 mai 2026',   icon:'🐑' },
]

export const ASMAUL_HUSNA = [
  { ar:'اللَّهُ',       phonetic:'Allah',      fr:"Dieu, Le Seul digne d'adoration" },
  { ar:'الرَّحْمَنُ',  phonetic:'Ar-Rahman',  fr:'Le Tout Miséricordieux'           },
  { ar:'الرَّحِيمُ',   phonetic:'Ar-Rahim',   fr:'Le Très Miséricordieux'           },
  { ar:'الْمَلِكُ',    phonetic:'Al-Malik',   fr:'Le Roi Absolu'                    },
  { ar:'الْقُدُّوسُ',  phonetic:'Al-Quddus',  fr:'Le Très Saint'                    },
  { ar:'السَّلَامُ',   phonetic:'As-Salam',   fr:'La Paix, Source de Paix'          },
  { ar:'الْعَزِيزُ',   phonetic:"Al-'Aziz",   fr:'Le Tout Puissant'                 },
  { ar:'الْخَالِقُ',   phonetic:'Al-Khaliq',  fr:'Le Créateur'                      },
  { ar:'الْغَفَّارُ',  phonetic:'Al-Ghaffar', fr:'Le Grand Pardonneur'              },
  { ar:'الرَّزَّاقُ',  phonetic:'Ar-Razzaq',  fr:'Le Pourvoyeur Suprême'            },
  { ar:'الْفَتَّاحُ',  phonetic:'Al-Fattah',  fr:"Le Juge, L'Ouvreur"              },
  { ar:'الْعَلِيمُ',   phonetic:"Al-'Alim",   fr:"L'Omniscient"                     },
  { ar:'الْحَكِيمُ',   phonetic:'Al-Hakim',   fr:'Le Sage Suprême'                  },
  { ar:'الْوَدُودُ',   phonetic:'Al-Wadud',   fr:'Le Tout Aimant'                   },
  { ar:'الْحَيُّ',     phonetic:'Al-Hayy',    fr:'Le Vivant Éternel'                },
  { ar:'الْقَيُّومُ',  phonetic:'Al-Qayyum',  fr:"L'Autosuffisant"                  },
  { ar:'الْوَاحِدُ',   phonetic:'Al-Wahid',   fr:"L'Unique"                         },
  { ar:'الأَحَدُ',     phonetic:'Al-Ahad',    fr:"L'Un Absolu"                      },
  { ar:'الصَّمَدُ',    phonetic:'As-Samad',   fr:"L'Éternel Absolu"                 },
  { ar:'الْقَادِرُ',   phonetic:'Al-Qadir',   fr:"L'Omnipotent"                     },
  { ar:'النُّورُ',     phonetic:'An-Nur',     fr:'La Lumière'                       },
  { ar:'الْهَادِي',    phonetic:'Al-Hadi',    fr:'Le Guide'                         },
  { ar:'التَّوَّابُ',  phonetic:'At-Tawwab',  fr:'Celui qui accepte le repentir'    },
  { ar:'الصَّبُورُ',   phonetic:'As-Sabur',   fr:'Le Très Patient'                  },
]
