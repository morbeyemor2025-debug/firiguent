// ─── airtable.js v22 ──────────────────────────────────────────────
// BUGS CORRIGÉS :
// 1. CRITIQUE : free_monthly_count + free_month_key retirés de createUser()
//    → ces champs n'existent pas dans Airtable → erreur login corrigée
// 2. free_used: false remis dans createUser() pour compatibilité
// 3. validatePayment : 30 jours (pas 180)
// 4. DIRECT_TOKEN retiré du bundle client — proxy only, pas de fallback direct
//    (sécurité : la clé ne doit pas être dans le JS livré au navigateur)

import { AIRTABLE_ENDPOINT } from './constants.js'

// ─── Requête via proxy Netlify ────────────────────────────────────
async function req(table, qs = '', method = 'GET', body = null) {
  let res
  try {
    res = await fetch(AIRTABLE_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ table, qs, method, payload: body }),
    })
  } catch (e) {
    throw new Error(`Connexion impossible. Vérifiez votre connexion internet. (${e.message})`)
  }

  if (!res.ok) {
    let msg = `Erreur ${res.status}`
    try {
      const j = await res.json()
      msg = j?.error?.message ?? j?.error?.type ?? j?.error ?? msg
    } catch {}
    throw new Error(msg)
  }

  return res.json()
}

async function fetchAll(table) {
  const records = []
  let offset = ''
  do {
    const qs   = offset ? `?offset=${encodeURIComponent(offset)}` : ''
    const data = await req(table, qs)
    records.push(...(data.records ?? []))
    offset = data.offset ?? ''
  } while (offset && records.length < 2000)
  return records
}

// ─── USERS ────────────────────────────────────────────────────────

export async function getUserByEmail(email) {
  const e       = email.toLowerCase().trim()
  const formula = encodeURIComponent(`{email}="${e}"`)
  const data    = await req('USERS', `?filterByFormula=${formula}&maxRecords=1`)
  return data.records?.[0] ?? null
}

export async function createUser(email, phone = '') {
  // FIX #1 CRITIQUE : ne plus envoyer free_monthly_count ni free_month_key
  // Ces champs n'existent pas dans Airtable → UNKNOWN_FIELD → login cassé
  // Le comptage mensuel est géré 100% en localStorage (voir auth.js)
  const fields = {
    email:     email.toLowerCase().trim(),
    plan:      'free',
    credits:   0,
    free_used: false,   // FIX #3 : remis pour compatibilité Dashboard + Admin
  }
  if (phone) fields.phone = phone

  const data = await req('USERS', '', 'POST', { records: [{ fields }] })
  return data.records[0]
}

export async function updateUser(recordId, fields) {
  return req('USERS', `/${recordId}`, 'PATCH', { fields })
}

export async function getUserById(recordId) {
  return req('USERS', `/${recordId}`)
}

export async function getAllUsers() {
  return fetchAll('USERS')
}

// ─── PAYMENTS ─────────────────────────────────────────────────────

export async function createPayment(userId, amount, userEmail = '', ref = '') {
  const fields = {
    user_id: [userId],
    amount:  Number(amount),
    status:  'pending',
  }
  if (userEmail) fields.user_email = userEmail
  if (ref)       fields.ref        = ref

  try {
    const data = await req('PAYMENTS', '', 'POST', { records: [{ fields }] })
    return data.records[0]
  } catch (e) {
    // Si user_email/ref n'existent pas encore dans la table → retry minimal
    if (e.message?.toLowerCase().includes('unknown field')) {
      const min  = { user_id: [userId], amount: Number(amount), status: 'pending' }
      const data = await req('PAYMENTS', '', 'POST', { records: [{ fields: min }] })
      return data.records[0]
    }
    throw e
  }
}

export async function getAllPayments() {
  return fetchAll('PAYMENTS')
}

export async function validatePayment(paymentRecordId, userId, amount) {
  const userRec = await getUserById(userId)
  if (!userRec) throw new Error('Utilisateur introuvable')
  const f = userRec.fields ?? {}

  // Valider le paiement
  await req('PAYMENTS', `/${paymentRecordId}`, 'PATCH', { fields: { status: 'validated' } })

  if (Number(amount) >= 5000) {
    // FIX #4 : abonnement = 30 jours (pas 180)
    const end = new Date()
    end.setDate(end.getDate() + 30)
    await req('USERS', `/${userId}`, 'PATCH', {
      fields: {
        plan:             'subscription',
        subscription_end: end.toISOString().split('T')[0],
        credits:          0,
      }
    })
  } else {
    // Paiement unique : +1 crédit
    await req('USERS', `/${userId}`, 'PATCH', {
      fields: {
        plan:    'one_time',
        credits: (Number(f.credits) || 0) + 1,
      }
    })
  }
}

// ─── INTERPRETATIONS ──────────────────────────────────────────────

export async function saveInterpretation(userId, dreamText, result, userEmail = '') {
  const fields = {
    user_id:    [userId],
    dream_text: (dreamText || '').slice(0, 10000),
    result:     (result    || '').slice(0, 50000),
  }
  if (userEmail) fields.user_email = userEmail

  try {
    const data = await req('INTERPRETATIONS', '', 'POST', { records: [{ fields }] })
    return data.records[0]
  } catch (e) {
    if (e.message?.toLowerCase().includes('unknown field')) {
      const min  = { user_id: [userId], dream_text: fields.dream_text, result: fields.result }
      const data = await req('INTERPRETATIONS', '', 'POST', { records: [{ fields: min }] })
      return data.records[0]
    }
    throw e
  }
}

export async function getUserInterpretations(userId) {
  const formula = encodeURIComponent(`FIND("${userId}", ARRAYJOIN({user_id}))`)
  const data    = await req('INTERPRETATIONS', `?filterByFormula=${formula}&maxRecords=50`)
  return data.records ?? []
}

export async function getAllInterpretations() {
  return fetchAll('INTERPRETATIONS')
}
