// ─── AuthContext.jsx v17 ──────────────────────────────────────────
// BUG CORRIGÉ : ne pas afficher le cache corrompu immédiatement.
// On attend la réponse FRAÎCHE d'Airtable avant de setUser.
// Si Airtable KO → fallback sur le cache.
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { getSession, refreshSession, clearSession } from './auth.js'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(async () => {
    const u = await refreshSession()
    setUser(u)
    return u
  }, [])

  const logout = useCallback(() => {
    clearSession()
    setUser(null)
  }, [])

  useEffect(() => {
    const init = async () => {
      const cached = getSession()
      if (!cached) { setLoading(false); return }

      // BUG CORRIGÉ : attendre Airtable d'abord, cache seulement en fallback
      try {
        const fresh = await refreshSession()
        setUser(fresh ?? cached)
      } catch {
        // Airtable KO → utiliser le cache tel quel
        setUser(cached)
      } finally {
        setLoading(false)
      }
    }
    init()
  }, [])

  return (
    <AuthContext.Provider value={{ user, setUser, loading, refresh, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
