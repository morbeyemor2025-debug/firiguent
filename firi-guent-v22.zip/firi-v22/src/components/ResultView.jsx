// ─── ResultView.jsx v22 ───────────────────────────────────────────
// Plans v20 :
//   Free  → aperçu 40% · jauge visuelle · CTA frustration
//   Once  → 1 000 FCFA · 1 interp. complète
//   Pro   → 5 000 FCFA · 6 mois illimités + journal mensuel

import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { RefreshCw, Share2, Copy, CheckCircle, Lock, BookOpen, Star, Zap } from 'lucide-react'
import { waPayLink, waExpertLink, waUnlockLink, PACKS, TIMES } from '../utils/constants.js'
import { createPayment } from '../utils/airtable.js'

// ─── Micro-testimonials ───────────────────────────────────────────
const MICRO_TESTIMONIALS = [
  { name:'Ibrahima S.', city:'Dakar',       text:'J\'ai reçu l\'analyse complète en 4 minutes. La précision sur les symboles était incroyable. Alhamdulillah.' },
  { name:'Aïssatou K.', city:'Saint-Louis', text:'Le serpent dans mon rêve m\'angoissait. L\'explication Ibn Sirin m\'a apaisée immédiatement.' },
]

function Testimonial({ t }) {
  return (
    <div style={{ padding:'10px 12px', background:'var(--bg)', border:'1px solid var(--card-border)', borderRadius:10, marginBottom:8 }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
        <div style={{ width:26, height:26, borderRadius:'50%', background:'var(--green-pale)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:'var(--green)', flexShrink:0 }}>
          {t.name[0]}
        </div>
        <div>
          <div style={{ fontSize:11, fontWeight:600, color:'var(--text)' }}>{t.name} · <span style={{ color:'var(--text-muted)', fontWeight:400 }}>{t.city}</span></div>
          <div style={{ display:'flex', gap:1 }}>
            {[1,2,3,4,5].map(i => <Star key={i} size={8} fill="var(--gold)" stroke="none"/>)}
          </div>
        </div>
      </div>
      <p style={{ fontSize:11, color:'var(--text-2)', margin:0, lineHeight:1.6, fontStyle:'italic' }}>"{t.text}"</p>
    </div>
  )
}

// ─── Jauge de progression 40% ─────────────────────────────────────
function UnlockGauge() {
  return (
    <div style={{ padding:'14px 16px', background:'#FFF7ED', border:'1.5px solid #FED7AA', borderRadius:12, marginTop:16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
        <span style={{ fontSize:12, fontWeight:600, color:'#9A3412' }}>Aperçu débloqué</span>
        <span style={{ fontSize:12, fontWeight:700, color:'#9A3412' }}>40%</span>
      </div>
      <div style={{ background:'#FDBA74', borderRadius:20, height:8, overflow:'hidden' }}>
        <div style={{ width:'40%', height:'100%', background:'linear-gradient(90deg,#EA580C,#F97316)', borderRadius:20, transition:'width 1s ease' }}/>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', marginTop:5 }}>
        <span style={{ fontSize:10, color:'#C2410C' }}>Type de rêve + Symbole principal</span>
        <span style={{ fontSize:10, color:'#9CA3AF' }}>60% restants 🔒</span>
      </div>
    </div>
  )
}

// ─── Preview floutée des 60% manquants ───────────────────────────
function LockedPreview() {
  return (
    <div style={{ position:'relative', margin:'16px 0' }}>
      <div style={{ padding:'16px', background:'var(--bg)', borderRadius:10, filter:'blur(5px)', userSelect:'none', pointerEvents:'none', fontSize:13, color:'var(--text-3)', lineHeight:1.8 }}>
        <p><strong>📖 Interprétation globale —</strong> Ibn Sirin précise dans son Tafsir al-Ahlam que ce type de vision appartient aux rêves de guidance divine. Les symboles révèlent une période de transition...</p>
        <p><strong>📜 Hadith Bukhari n°6499 —</strong> Le Prophète ﷺ a dit : ce rêve correspond aux caractéristiques de la Ru'ya Rahmâniyya. Les Compagnons témoignent...</p>
        <p><strong>🤲 Du'a personnalisé —</strong> اللَّهُمَّ أَرِنَا الحَقَّ حَقًّا وَارْزُقْنَا اتِّبَاعَهُ...</p>
      </div>
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
        <div style={{ background:'rgba(255,255,255,.96)', backdropFilter:'blur(4px)', borderRadius:12, padding:'14px 22px', textAlign:'center', border:'1.5px solid var(--card-border)' }}>
          <Lock size={18} style={{ color:'#EA580C', display:'block', margin:'0 auto 6px' }}/>
          <div style={{ fontSize:13, fontWeight:600, color:'var(--text)' }}>60% de l'analyse verrouillée</div>
          <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>Interprétation · Hadiths · Du'a complet</div>
        </div>
      </div>
    </div>
  )
}

function Prose({ text }) {
  const nodes = useMemo(() => {
    if (!text) return []
    return text.split('\n').filter(l => l.trim()).map((line, i) => {
      const t = line.trim()
      if (/^\*\*[^*]+\*\*$/.test(t)) return <span key={i} className="st">{t.replace(/\*\*/g, '')}</span>
      if (/[\u0600-\u06FF]{5,}/.test(t)) return (
        <div key={i} className="arabic-block my-4">
          <div className="arabic-script">{t.replace(/\*\*/g, '')}</div>
        </div>
      )
      if (/^---+$/.test(t)) return <hr key={i} style={{ margin:'12px 0', borderColor:'var(--card-border)' }} />
      return <p key={i} className="my-2" dangerouslySetInnerHTML={{ __html: t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>') }} />
    })
  }, [text])
  return <div className="prose-r">{nodes}</div>
}

function CopyBtn({ text, label = 'Copier' }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    try { await navigator.clipboard.writeText(text) } catch {
      const el = document.createElement('textarea')
      el.value = text; document.body.appendChild(el); el.select()
      document.execCommand('copy'); document.body.removeChild(el)
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy} style={{ padding:'7px 10px', borderRadius:8, border:'1.5px solid var(--card-border)', background:'#fff', cursor:'pointer', color: copied ? 'var(--green)' : 'var(--text-muted)', display:'flex', alignItems:'center', gap:4, fontSize:12, transition:'all .2s', whiteSpace:'nowrap' }}>
      {copied ? <CheckCircle size={13}/> : <Copy size={13}/>}
      {copied ? 'Copié !' : label}
    </button>
  )
}

const WaIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

// ─── Pack card ────────────────────────────────────────────────────
function PackCard({ pack, user, dreamId, onPackClick, isSelected }) {
  const isPro = pack.subscription
  return (
    <a
      href={waPayLink(pack, user?.email || '', dreamId || '')}
      target="_blank" rel="noreferrer"
      onClick={() => onPackClick(pack)}
      style={{
        display:'flex', flexDirection:'column', gap:8,
        padding:'16px', borderRadius:14,
        border: pack.popular ? '2.5px solid var(--blue)' : isPro ? '2px solid var(--green)' : '1.5px solid var(--card-border)',
        background: pack.popular ? 'var(--blue-pale)' : isPro ? 'var(--green-pale)' : '#fff',
        textDecoration:'none', transition:'all .18s', cursor:'pointer',
        boxShadow: pack.popular ? '0 4px 16px rgba(30,64,175,.12)' : isPro ? '0 4px 16px rgba(15,110,86,.1)' : 'var(--card-shadow)',
        position:'relative',
      }}
    >
      {pack.popular && (
        <div style={{ position:'absolute', top:-11, left:'50%', transform:'translateX(-50%)', background:'var(--blue)', color:'#fff', borderRadius:20, padding:'2px 12px', fontSize:10, fontWeight:700, whiteSpace:'nowrap' }}>
          ⚡ DÉBLOQUAGE IMMÉDIAT
        </div>
      )}
      {isPro && (
        <div style={{ position:'absolute', top:-11, left:'50%', transform:'translateX(-50%)', background:'var(--green)', color:'#fff', borderRadius:20, padding:'2px 12px', fontSize:10, fontWeight:700, whiteSpace:'nowrap' }}>
          🏆 MEILLEURE VALEUR
        </div>
      )}
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <WaIcon size={16}/>
        <div style={{ flex:1 }}>
          <div style={{ fontWeight:700, fontSize:14, color: pack.popular ? 'var(--blue-text)' : isPro ? '#0F6E56' : 'var(--text)' }}>
            {pack.label}
          </div>
          <div style={{ fontSize:12, color:'var(--text-muted)' }}>{pack.highlight}</div>
        </div>
        <div style={{ textAlign:'right', flexShrink:0 }}>
          <div style={{ fontFamily:"'Amiri',serif", fontSize:18, fontWeight:700, color: pack.popular ? 'var(--blue)' : isPro ? 'var(--green)' : 'var(--text)' }}>
            {pack.fcfa}
          </div>
        </div>
      </div>
      {pack.bonus && (
        <div style={{ fontSize:11, color:'var(--gold)', fontWeight:600, padding:'4px 8px', background:'rgba(251,191,36,.1)', borderRadius:6 }}>
          🎁 {pack.bonus}
        </div>
      )}
    </a>
  )
}

export default function ResultView({ result, form, dreamId, onRestart, user }) {
  const [payStep, setPayStep] = useState(0)
  const [sentPack, setSentPack] = useState(null)
  const isSubscriber = user?.plan === 'subscription'
  const tLabel = TIMES.find(t => t.v === form?.time)?.label ?? form?.time

  const handlePackClick = async (pack) => {
    setSentPack(pack)
    setPayStep(1)
    if (user?.id) {
      try { await createPayment(user.id, pack.price, user.email || '', dreamId || '') } catch {}
    }
  }

  const share = () => {
    const txt = `J'ai reçu une interprétation islamique de mon rêve sur Firi Guent : ${window.location.origin}`
    if (navigator.share) navigator.share({ title:'Firi Guent', text:txt, url:window.location.origin }).catch(()=>{})
    else navigator.clipboard?.writeText(txt).catch(()=>{})
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

      {/* Référence */}
      {dreamId && (
        <div className="card-blue" style={{ padding:'12px 18px', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:10 }}>
          <div>
            <div className="label-sm" style={{ color:'var(--blue)', marginBottom:3 }}>Référence de votre rêve</div>
            <div style={{ fontFamily:"'Amiri',serif", fontSize:22, fontWeight:700, color:'var(--blue-text)', letterSpacing:'0.05em' }}>#{dreamId}</div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:11, color:'var(--text-muted)' }}>Conservez ce numéro</span>
            <CopyBtn text={dreamId} />
          </div>
        </div>
      )}

      {/* Résultat principal */}
      <div className="card" style={{ padding:'24px 24px 20px' }}>
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12, marginBottom:18 }}>
          <div>
            <div className="label-sm" style={{ color:'var(--green)', marginBottom:4 }}>تفسير الرُّؤْيَا · Tafsir ar-Ru'ya</div>
            <h2 style={{ fontFamily:"'Amiri',serif", fontSize:'1.5rem', fontWeight:700, color:'var(--text)', marginBottom:3 }}>Votre Interprétation</h2>
            <p style={{ fontSize:12, color:'var(--text-muted)', margin:0 }}>Sheikh Momar · Ibn Sirin · Al-Nabulsi · Dakar 🇸🇳</p>
          </div>
          <div style={{ display:'flex', gap:6, flexShrink:0 }}>
            <CopyBtn text={result?.text || ''} />
            <button onClick={share} style={{ padding:'7px 10px', borderRadius:8, border:'1.5px solid var(--card-border)', background:'#fff', cursor:'pointer', color:'var(--text-muted)', display:'flex', alignItems:'center', gap:4, fontSize:12 }}>
              <Share2 size={13}/> Partager
            </button>
          </div>
        </div>

        {/* Récap rêve */}
        <div style={{ padding:'12px 14px', background:'var(--bg)', border:'1.5px solid var(--card-border)', borderRadius:10, marginBottom:16 }}>
          <div className="label-sm" style={{ color:'var(--text-muted)', marginBottom:6 }}>Rêve analysé</div>
          <p style={{ fontSize:13, color:'var(--text-2)', fontStyle:'italic', margin:'0 0 4px', display:'-webkit-box', WebkitLineClamp:3, WebkitBoxOrient:'vertical', overflow:'hidden' }}>
            "{form?.text}"
          </p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:10, fontSize:11, color:'var(--text-muted)' }}>
            {form?.emotion && <span>Émotion : {form.emotion}</span>}
            {tLabel && <><span>·</span><span>{tLabel}</span></>}
          </div>
        </div>

        {/* Texte de l'analyse */}
        <Prose text={result?.text} />

        {/* Jauge 40% + preview floutée (seulement si pas abonné/crédits) */}
        {!isSubscriber && Number(user?.credits || 0) === 0 && (
          <>
            <UnlockGauge />
            <LockedPreview />
          </>
        )}

        {/* Wallahu A'lam — seulement si abonné (analyse complète) */}
        {(isSubscriber || Number(user?.credits || 0) > 0) && (
          <div className="arabic-block" style={{ marginTop:20 }}>
            <div className="arabic-script">وَاللَّهُ أَعْلَمُ</div>
            <div className="arabic-phonetic">Wallahu A'lam</div>
            <div className="arabic-translation">Et Allah seul connaît la vérité absolue</div>
          </div>
        )}
      </div>

      {/* ─── SECTION UPGRADE (seulement si pas abonné) ─────────────── */}
      {!isSubscriber && (
        <div style={{ background:'var(--card)', border:'1.5px solid var(--card-border)', borderRadius:16, padding:'22px', overflow:'hidden', position:'relative' }}>
          <div className="geo" style={{ position:'absolute', inset:0, opacity:.4, pointerEvents:'none' }}/>
          <div style={{ position:'relative', zIndex:1 }}>

            {/* Header incitation */}
            <div style={{ marginBottom:14 }}>
              <h3 style={{ fontFamily:"'Amiri',serif", fontSize:'1.2rem', fontWeight:700, color:'var(--text)', marginBottom:6 }}>
                🔓 Débloquez les 60% restants
              </h3>
              <p style={{ fontSize:13, color:'var(--text-3)', lineHeight:1.7, margin:0 }}>
                <strong>Allah vous a envoyé ce rêve pour une raison.</strong> Ne repartez pas avec seulement 40% du message.
                L'interprétation globale, les hadiths authentiques et votre du'a personnalisé vous attendent.
              </p>
            </div>

            {/* Micro-testimonials */}
            <div style={{ marginBottom:14 }}>
              {MICRO_TESTIMONIALS.map((t,i) => <Testimonial key={i} t={t}/>)}
            </div>

            {/* Packs */}
            {payStep === 0 && (
              <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                {PACKS.map(pack => (
                  <PackCard key={pack.id} pack={pack} user={user} dreamId={dreamId} onPackClick={handlePackClick}/>
                ))}
                <p style={{ fontSize:11, color:'var(--text-muted)', textAlign:'center', margin:'4px 0 0' }}>
                  Cliquez → WhatsApp s'ouvre → Envoyez preuve Wave · <strong>Validation sous 5 min</strong> · <em style={{ color:'var(--gold)' }}>In sha Allah</em>
                </p>
              </div>
            )}

            {/* Instructions post-clic */}
            {payStep === 1 && sentPack && (
              <div style={{ background:'#fff', borderRadius:12, padding:'16px', border:'1px solid var(--card-border)' }}>
                <div style={{ fontWeight:600, color:'var(--text)', marginBottom:10 }}>
                  ✅ WhatsApp ouvert — {sentPack.label} ({sentPack.fcfa})
                </div>
                <ol style={{ paddingLeft:18, color:'var(--text-3)', fontSize:13, lineHeight:2 }}>
                  <li>Prenez une capture d'écran de votre paiement Wave</li>
                  <li>Envoyez-la dans le message WhatsApp ouvert</li>
                  <li>Notre équipe valide sous <strong>5 minutes</strong> · <em style={{ color:'var(--gold)' }}>In sha Allah</em></li>
                </ol>
                <div style={{ display:'flex', gap:8, marginTop:12 }}>
                  <a href={waUnlockLink(dreamId, user?.email)} target="_blank" rel="noreferrer"
                    className="btn btn-wa" style={{ flex:1, justifyContent:'center', padding:'11px', fontSize:13, borderRadius:10 }}>
                    <WaIcon /> Renvoyer le message
                  </a>
                  <CopyBtn text={`Ref: ${dreamId || '—'} — Email: ${user?.email || '—'}`} label="Copier ref" />
                </div>
                <button onClick={() => setPayStep(0)} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:12, cursor:'pointer', marginTop:8, textDecoration:'underline' }}>
                  ← Changer de pack
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ─── JOURNAL MENSUEL (Pro) ────────────────────────────────── */}
      {isSubscriber ? (
        <div className="card" style={{ padding:'20px', border:'2px solid var(--green)', borderRadius:16 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
            <BookOpen size={20} style={{ color:'var(--green)', flexShrink:0 }}/>
            <div>
              <div style={{ fontWeight:700, fontSize:14, color:'var(--text)' }}>📔 Journal des Rêves Mensuel</div>
              <div style={{ fontSize:12, color:'var(--green)' }}>Inclus dans votre abonnement Pro</div>
            </div>
          </div>
          <p style={{ fontSize:13, color:'var(--text-3)', margin:'0 0 12px', lineHeight:1.7 }}>
            Ce rêve est ajouté à votre journal. En fin de mois, Sheikh Momar vous envoie un rapport psycho-spirituel complet sur tous vos rêves du mois.
          </p>
          <Link to="/dashboard" className="btn btn-primary" style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'10px 16px', borderRadius:12, fontSize:13 }}>
            <BookOpen size={14}/> Voir mon journal
          </Link>
        </div>
      ) : (
        <div style={{ padding:'16px 18px', background:'linear-gradient(135deg,#f0fdf4,#ecfdf5)', border:'1.5px solid #A7F3D0', borderRadius:14 }}>
          <div style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
            <span style={{ fontSize:22, flexShrink:0 }}>📔</span>
            <div>
              <div style={{ fontWeight:700, fontSize:13, color:'var(--text)', marginBottom:3 }}>Journal mensuel des rêves — Plan Pro</div>
              <p style={{ fontSize:12, color:'var(--text-3)', margin:'0 0 8px', lineHeight:1.6 }}>
                Abonnez-vous 6 mois et recevez chaque mois un rapport complet sur tous vos rêves. Thèmes récurrents, évolution spirituelle, guidance personnalisée.
              </p>
              <span style={{ fontSize:11, color:'var(--green)', fontWeight:600 }}>✓ Inclus dans le Pro à 5 000 FCFA / 6 mois</span>
            </div>
          </div>
        </div>
      )}

      {/* Expert CTA */}
      <div className="card" style={{ padding:'16px 20px', display:'flex', flexDirection:'column', gap:8 }}>
        <div style={{ fontSize:13, fontWeight:600, color:'var(--text)' }}>🕌 Consulter un expert directement</div>
        <p style={{ fontSize:12, color:'var(--text-3)', margin:0 }}>Sadaqa, Istikhar, guidance spirituelle — nos experts sénégalais répondent personnellement.</p>
        <a href={waExpertLink(user?.email || '')} target="_blank" rel="noreferrer"
          className="btn btn-wa" style={{ justifyContent:'center', borderRadius:12, padding:'11px' }}>
          <WaIcon size={15}/> Consulter un expert
        </a>
      </div>

      {/* Actions */}
      <div style={{ display:'flex', gap:10 }}>
        <button onClick={onRestart} className="btn btn-outline" style={{ flex:1, justifyContent:'center', padding:'13px', borderRadius:12 }}>
          <RefreshCw size={15}/> Nouveau rêve
        </button>
        <Link to="/dashboard" className="btn btn-primary" style={{ flex:1, justifyContent:'center', padding:'13px', borderRadius:12 }}>
          Voir mon historique
        </Link>
      </div>

    </div>
  )
}
