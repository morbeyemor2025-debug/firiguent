import React, { useState, useMemo } from 'react'
import { Search } from 'lucide-react'
import { Link } from 'react-router-dom'
import { waNotFoundLink } from '../utils/constants.js'

const DICT = [
  { ar:'مَاء',     phonetic:"Mâ' (Eau)",        fr:'Eau',        cat:'Nature',
    free:"Selon Ibn Sirin, l'eau claire représente la vie, la purification et la connaissance divine. Boire de l'eau pure annonce une longue vie bénie et des bienfaits spirituels considérables. In sha Allah, ce symbole est généralement porteur d'espoir.",
    premium:"Al-Nabulsi précise que l'eau trouble signale des épreuves imminentes. Un fleuve en crue symbolise un souverain ou une grande autorité dans la vie du rêveur." },
  { ar:'نَار',     phonetic:'Nâr (Feu)',          fr:'Feu',        cat:'Nature',
    free:"Le feu dans un rêve islamique peut symboliser la guidance et la lumière spirituelle. Un feu sans fumée annonce une lumière divine qui éclaire le chemin du rêveur. Ibn Sirin le considère comme un signe ambivalent qui doit être interprété selon le contexte.",
    premium:"Ibn Sirin distingue : le feu qui éclaire sans brûler = connaissance et foi ; le feu destructeur = fitna (discorde) ou conflit à venir." },
  { ar:'نُور',     phonetic:'Nûr (Lumière)',       fr:'Lumière',    cat:'Nature',
    free:"La lumière est parmi les symboles les plus bénis du Tafsir al-Ahlam. Ibn Sirin affirme : voir la lumière descendre du ciel est un signe clair de guidance divine accordée au rêveur. In sha Allah, ce rêve annonce de bonnes nouvelles.",
    premium:"Al-Nabulsi précise qu'une lumière venant de la maison annonce une naissance bénie ou l'arrivée d'un grand savant dans la famille. La lumière verte symbolise la foi pure." },
  { ar:'شَمْس',    phonetic:'Shams (Soleil)',      fr:'Soleil',     cat:'Nature',
    free:"Le soleil représente le roi, le père ou l'autorité suprême. Le voir briller intensément dans un rêve annonce puissance et honneur. C'est un signe généralement positif selon Ibn Sirin.",
    premium:"Ibn Sirin précise : si une femme voit le soleil entrer dans sa maison, son époux sera une personne de grand rang. Le coucher du soleil peut signaler un deuil ou la fin d'une période." },
  { ar:'قَمَر',    phonetic:'Qamar (Lune)',        fr:'Lune',       cat:'Nature',
    free:"La lune représente la mère, l'épouse ou un ministre. Une pleine lune éclatante annonce gloire et réussite sociale. In sha Allah, ce rêve est porteur de bonnes nouvelles pour la famille.",
    premium:"Al-Nabulsi précise : tenir la lune dans ses mains annonce un mariage imminent ou la naissance d'un enfant vertueux et bien guidé. Un croissant de lune = début d'une nouvelle période." },
  { ar:'مَطَر',    phonetic:'Matar (Pluie)',       fr:'Pluie',      cat:'Nature',
    free:"La pluie est le signe de la miséricorde divine (رَحْمَة — Rahma). Ibn Sirin dit : rêver de pluie annonce une délivrance proche et un retour de la grâce d'Allah. In sha Allah, ce rêve apporte l'espoir.",
    premium:"La pluie de sang = catastrophe ou grande injustice. La pluie de miel = connaissance, bénédictions et abondance spirituelles." },
  { ar:'ثُعْبَان',  phonetic:"Thu'bân (Serpent)",  fr:'Serpent',    cat:'Animaux',
    free:"Le serpent est l'un des symboles les plus complexes. Ibn Sirin précise : il représente selon le contexte un ennemi caché, un conflit imminent, ou une richesse dissimulée. Ne vous inquiétez pas — reve-islam.com confirme que tuer le serpent en rêve annonce la victoire sur vos difficultés.",
    premium:"Tuer le serpent = victoire décisive. Être mordu = trahison imminente. Serpent blanc = ennemi faible. Serpent dans la maison = ennemi parmi les proches." },
  { ar:'أَسَد',    phonetic:'Asad (Lion)',         fr:'Lion',       cat:'Animaux',
    free:"Le lion symbolise un roi tyrannique ou une autorité redoutable. Selon Ibn Sirin, fuir un lion indique une épreuve difficile avec une personne d'autorité. Monter un lion annonce la victoire.",
    premium:"Ibn Sirin : monter sur un lion = surmonter un obstacle puissant avec succès. Être attaqué = risque de conflit avec un homme de pouvoir." },
  { ar:'طَيْر',    phonetic:'Tayr (Oiseau)',       fr:'Oiseau',     cat:'Animaux',
    free:"L'oiseau symbolise l'âme, la liberté et les nouvelles venues de loin. Un oiseau chantant dans un rêve est parmi les plus belles annonces de bonnes nouvelles. In sha Allah, ce signe est très favorable.",
    premium:"Al-Nabulsi : un oiseau blanc = bonnes nouvelles pures ; noir = nouvelles tristes. Un oiseau qui s'envole depuis la maison signale un départ ou une séparation." },
  { ar:'فَرَس',    phonetic:'Faras (Cheval)',      fr:'Cheval',     cat:'Animaux',
    free:"Le cheval représente la noblesse, la dignité et l'ascension sociale. Ibn Sirin dit : monter un beau cheval annonce un rang social élevé et un honneur durable. In sha Allah, ce rêve est très positif.",
    premium:"Al-Nabulsi : cheval noir = richesse prochaine. Cheval blanc = prestige et victoire. Cheval qui s'échappe = risque de perte de statut social." },
  { ar:'كَلْب',    phonetic:'Kalb (Chien)',        fr:'Chien',      cat:'Animaux',
    free:"Selon Ibn Sirin, le chien représente un ennemi déclaré ou un adversaire. Sa présence est généralement un avertissement à prendre au sérieux dans votre vie actuelle.",
    premium:"Un chien qui aboie sans mordre = ennemi qui menace sans agir. Un chien blanc = ennemi de bonne famille mais potentiellement dangereux." },
  { ar:'يَد',     phonetic:'Yad (Main)',           fr:'Main',       cat:'Corps',
    free:"La main représente le pouvoir d'action et la générosité. Selon Ibn Sirin, des mains coupées annoncent une perte de moyens. Des mains brillantes annoncent générosité récompensée.",
    premium:"Main droite coupée = perte de richesse. Main gauche = perte d'un proche. Main qui brille = générosité reconnue et récompensée par Allah." },
  { ar:'عَيْن',   phonetic:"'Ayn (Œil)",          fr:'Œil',        cat:'Corps',
    free:"Les yeux symbolisent la clairvoyance spirituelle et le jugement. Voir avec des yeux lumineux signifie que guidance et foi s'accroissent. C'est un signe positif selon le Tafsir al-Ahlam.",
    premium:"Ibn Sirin : yeux malades = problèmes avec ses proches. Yeux supplémentaires = don de connaissance extraordinaire accordé par Allah." },
  { ar:'سِنّ',    phonetic:'Sinn (Dent)',          fr:'Dent',       cat:'Corps',
    free:"Les dents représentent les membres de la famille : supérieures = hommes, inférieures = femmes. Ce symbole est très précis selon Ibn Sirin et Al-Nabulsi dans leurs ouvrages de référence.",
    premium:"Une dent qui tombe sans douleur = perte d'un membre de la famille. Une dent en or = gains financiers qui viendront après une épreuve." },
  { ar:'مَسْجِد',  phonetic:'Masjid (Mosquée)',    fr:'Mosquée',    cat:'Lieux',
    free:"La mosquée est parmi les symboles les plus bénis. Y entrer annonce sécurité et succès. Selon reve-islam.com et Ibn Sirin, construire une mosquée annonce un mariage ou un poste important. In sha Allah, ce rêve est excellent.",
    premium:"Construire une mosquée = grande œuvre pieuse récompensée. Mosquée détruite = communauté en péril spirituel. Pleurer dans une mosquée = bon rêve, amélioration de la vie." },
  { ar:'بَيْت',   phonetic:'Bayt (Maison)',        fr:'Maison',     cat:'Lieux',
    free:"La maison représente le corps ou la famille du rêveur. Une belle maison spacieuse et lumineuse annonce un état d'esprit serein et une vie familiale équilibrée. In sha Allah, c'est un signe d'harmonie.",
    premium:"Maison qui s'effondre = risque de maladie grave. Maison neuve = mariage imminent ou nouveau départ. Maison sombre = épreuves spirituelles à traverser." },
  { ar:'سَفَر',   phonetic:'Safar (Voyage)',       fr:'Voyage',     cat:'Lieux',
    free:"Un voyage en rêve annonce un changement important de situation. Selon Ibn Sirin, il symbolise une migration vers de nouveaux horizons ou une évolution spirituelle. In sha Allah, ce changement sera bénéfique.",
    premium:"Voyage vers La Mecque = accomplissement d'un devoir religieux. Voyage sans destination = perte de direction dans la vie réelle actuelle." },
  { ar:'بَحْر',   phonetic:'Bahr (Mer/Océan)',     fr:'Mer/Océan',  cat:'Lieux',
    free:"La mer symbolise une grande autorité ou un domaine vaste. Naviguer sur une mer calme annonce une vie aisée. Ibn Sirin considère ce rêve comme très significatif pour l'avenir du rêveur.",
    premium:"Se noyer dans la mer = être submergé par les affaires d'un puissant. Mer asséchée = fin d'une ère importante ou mort d'un roi." },
  { ar:'النَّبِيّ', phonetic:'An-Nabi (Prophète ﷺ)', fr:'Prophète ﷺ', cat:'Spirituel',
    free:"Voir le Prophète Muhammad ﷺ est l'un des rêves les plus bénis. Il a dit lui-même : 'Celui qui me voit en rêve m'a vraiment vu, car le Shaytân ne peut prendre ma forme.' (Bukhari). C'est une grâce immense.",
    premium:"Recevoir quelque chose des mains du Prophète ﷺ = bénédiction extraordinaire. Le voir souffrant = la Oumma traverse une épreuve collective." },
  { ar:'الكَعْبَة', phonetic:"Al-Ka'ba (Kaaba)",   fr:'Kaaba',      cat:'Spirituel',
    free:"Voir la Kaaba est un signe de grande bénédiction. Effectuer le tawaf annonce la réalisation d'un vœu ou l'accomplissement du Hajj. In sha Allah, ce rêve annonce de grandes bénédictions pour le rêveur.",
    premium:"Entrer à l'intérieur de la Kaaba = accès à la guidance divine suprême. Kaaba détruite = grand malheur pour la Oumma islamique." },
  { ar:'القُرْآن', phonetic:"Al-Qur'an (Coran)",   fr:'Coran',      cat:'Spirituel',
    free:"Voir, lire ou entendre le Coran en rêve est un signe de guidance divine et de lumière spirituelle. Ibn Sirin classe ce rêve parmi les meilleures visions. In sha Allah, ce rêve annonce une croissance spirituelle.",
    premium:"Réciter le Coran avec aisance = croissance spirituelle. Le voir brûler = négligence dans sa relation avec Allah." },
]

export default function SymbolSearch() {
  const [query, setQuery] = useState('')
  const [active, setActive] = useState(null)
  const [cat, setCat] = useState('Tous')

  const cats = ['Tous', ...new Set(DICT.map(d => d.cat))]

  const results = useMemo(() => {
    const q = query.toLowerCase().trim()
    return DICT.filter(d => {
      const matchCat = cat === 'Tous' || d.cat === cat
      if (!q) return matchCat
      return matchCat && (d.fr.toLowerCase().includes(q) || d.phonetic.toLowerCase().includes(q) || d.cat.toLowerCase().includes(q) || d.free.toLowerCase().includes(q) || d.ar.includes(q))
    })
  }, [query, cat])

  return (
    <section className="z1 px-4 pb-20 max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="arabic-block inline-flex flex-col items-center px-8 py-3 mx-auto mb-4">
          <div className="arabic-script text-2xl">مُعْجَمُ الرُّؤَى</div>
          <div className="arabic-phonetic">Mu'jam ar-Ru'ya — Dictionnaire des rêves</div>
        </div>
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-2" style={{color:'var(--text)'}}>
          Symboles islamiques des rêves
        </h2>
        <p className="text-sm" style={{color:'var(--text-3)'}}>
          Selon Ibn Sirin, Al-Nabulsi et reve-islam.com
        </p>
      </div>

      <div className="relative mb-4">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{color:'var(--text-muted)'}} />
        <input type="text" value={query} onChange={e => setQuery(e.target.value)}
          className="field pl-11"
          placeholder="Chercher : serpent, eau, mosquée, lion, maison… (Fr, phonétique ou arabe)" />
      </div>

      <div className="flex flex-wrap gap-2 mb-5">
        {cats.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
              cat === c
                ? 'text-white'
                : 'text-[var(--text-3)] border border-gray-200 hover:border-[var(--blue)] hover:text-[var(--blue)]'
            }`}
            style={cat === c ? { background: 'var(--blue)' } : {}}>
            {c}
          </button>
        ))}
      </div>

      <p className="text-xs mb-4" style={{color:'var(--text-muted)'}}>
        {results.length} symbole{results.length > 1 ? 's' : ''}
        {query && <> pour "<strong style={{color:'var(--blue)'}}>{query}</strong>"</>}
      </p>

      <div className="space-y-2.5">
        {results.map((sym, i) => (
          <div key={i} className="card overflow-hidden hover:border-[rgba(59,130,246,.3)] transition-all">
            <button onClick={() => setActive(active === i ? null : i)}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4 flex-1 min-w-0">
                <div style={{fontFamily:"'Scheherazade New',serif", fontSize:'1.9rem', color:'var(--green)', minWidth:'52px', textAlign:'center', direction:'rtl'}}>
                  {sym.ar}
                </div>
                <div>
                  <div className="font-display text-base font-semibold" style={{color:'var(--text)'}}>{sym.fr}</div>
                  <div style={{fontFamily:"'Amiri',serif", color:'var(--blue)', fontSize:'.9rem', fontStyle:'italic'}}>
                    {sym.phonetic}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="text-xs px-2 py-0.5 rounded-full border border-gray-100 hidden sm:block" style={{color:'var(--text-muted)'}}>
                  {sym.cat}
                </span>
                <span className="text-base" style={{color:'var(--text-muted)'}}>{active === i ? '▲' : '▼'}</span>
              </div>
            </button>

            {active === i && (
              <div className="border-t border-gray-100 p-5">
                <div className="mb-4">
                  <span className="badge-green text-xs mb-2 inline-flex">🎁 Interprétation — Sheikh Momar</span>
                  <p className="text-sm leading-relaxed mt-2" style={{color:'var(--text-2)'}}>{sym.free}</p>
                </div>
                <div className="relative rounded-xl overflow-hidden">
                  <div className="p-4 rounded-xl text-sm leading-relaxed" style={{filter:'blur(3.5px)', userSelect:'none', pointerEvents:'none', background:'var(--card)', color:'var(--text-3)'}}>
                    {sym.premium}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Link to="/interpreter" className="bg-white/90 backdrop-blur-sm rounded-xl px-4 py-2.5 text-center border border-gray-200 hover:border-[var(--blue)] transition-all">
                      <div className="text-sm font-semibold" style={{color:'var(--blue-deep)'}}>🔒 Analyse complète — 1 000 FCFA Wave</div>
                      <div className="text-xs mt-0.5" style={{color:'var(--text-muted)'}}>Réponse sur WhatsApp · In sha Allah</div>
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {results.length === 0 && (
        <div className="card p-8 text-center mt-4">
          <div className="text-3xl mb-3">🔍</div>
          <h3 className="font-display text-xl font-semibold mb-2" style={{color:'var(--text)'}}>Symbole introuvable</h3>
          <p className="text-sm mb-5" style={{color:'var(--text-3)'}}>
            Ce symbole n'est pas encore dans notre dictionnaire. Nos experts peuvent vous aider.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href={waNotFoundLink(query)} target="_blank" rel="noreferrer"
              className="btn btn-wa px-6 py-3 rounded-xl text-sm">💬 Demander sur WhatsApp</a>
            <Link to="/interpreter" className="btn btn-outline px-6 py-3 rounded-xl text-sm">
              🌙 Interpréter mon rêve complet
            </Link>
          </div>
        </div>
      )}
    </section>
  )
}
