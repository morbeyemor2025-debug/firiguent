// ─── Navbar.jsx v21 — Luxe Arabesque ────────────────────────────
import React, { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { BookOpen, LayoutDashboard, Menu, X, Sparkles, Moon } from 'lucide-react'
import { useAuth } from '../utils/AuthContext.jsx'
import { freeRemainingThisMonth, FREE_MONTHLY_LIMIT } from '../utils/auth.js'

const LINKS = [
  { to:'/interpreter',  label:'Interpréter',  Icon:BookOpen,        public:false },
  { to:'/asmaul-husna', label:'99 Noms',       Icon:Sparkles,        public:true  },
  { to:'/dashboard',    label:'Mes Rêves',     Icon:LayoutDashboard, public:false },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen]         = useState(false)
  const { pathname }            = useLocation()
  const { user, logout }        = useAuth()

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 30)
    window.addEventListener('scroll', h, { passive:true })
    return () => window.removeEventListener('scroll', h)
  }, [])
  useEffect(() => setOpen(false), [pathname])

  const visibleLinks = LINKS.filter(l => l.public || user)
  const isHero = ['/',''].includes(pathname) || pathname === '/login'
  const isDark = isHero && !scrolled

  const AccessPill = () => {
    if (!user) return null
    if (user.plan === 'subscription') {
      return (
        <span style={{ fontFamily:"'Outfit',sans-serif", fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:100, background:'rgba(11,77,46,.12)', color:'var(--emerald)', border:'1px solid rgba(11,77,46,.2)' }}>
          ♾️ Pro actif
        </span>
      )
    }
    if (Number(user.credits) > 0) {
      return (
        <span style={{ fontFamily:"'Outfit',sans-serif", fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:100, background:'rgba(139,105,20,.1)', color:'var(--gold)', border:'1px solid rgba(139,105,20,.2)' }}>
          💎 {user.credits} crédit{user.credits > 1 ? 's' : ''}
        </span>
      )
    }
    const remaining = freeRemainingThisMonth(user)
    if (remaining > 0) {
      return (
        <span style={{ fontFamily:"'Outfit',sans-serif", fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:100, background:'rgba(11,77,46,.08)', color:'var(--emerald-mid)', border:'1px solid rgba(11,77,46,.15)' }}>
          🎁 {remaining}/{FREE_MONTHLY_LIMIT} ce mois
        </span>
      )
    }
    return (
      <span style={{ fontFamily:"'Outfit',sans-serif", fontSize:11, fontWeight:600, padding:'3px 10px', borderRadius:100, background:'rgba(153,27,27,.08)', color:'#991B1B', border:'1px solid rgba(153,27,27,.2)' }}>
        🔒 Recharger
      </span>
    )
  }

  return (
    <header
      className="fixed top-0 inset-x-0 z-50 transition-all duration-300"
      style={scrolled ? {
        background: 'rgba(253,250,245,.97)',
        boxShadow: '0 1px 0 #DDD5C5, 0 4px 24px rgba(15,29,13,.07)',
        backdropFilter: 'blur(16px)',
      } : {
        background: 'transparent',
      }}
    >
      {/* Ligne dorée top */}
      {scrolled && (
        <div style={{ height:2, background:'linear-gradient(to right, transparent, #C9A84C 20%, #E8C96A 50%, #B8860B 80%, transparent)', opacity:.7 }}/>
      )}

      <nav style={{ maxWidth:1140, margin:'0 auto', padding:'0 24px', height:68, display:'flex', alignItems:'center', justifyContent:'space-between' }}>

        {/* Logo */}
        <Link to="/" style={{ display:'flex', alignItems:'center', gap:10, textDecoration:'none', flexShrink:0 }}>
          <div style={{
            width:36, height:36, borderRadius:'50%',
            background: isDark ? 'rgba(139,105,20,.25)' : 'var(--gold-pale)',
            border: `1.5px solid ${isDark ? 'rgba(200,170,80,.4)' : 'var(--gold-soft)'}`,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:18,
          }}>
            🌙
          </div>
          <div>
            <div style={{
              fontFamily:"'Cormorant Garamond',serif",
              fontSize:20, fontWeight:700, lineHeight:1.1,
              color: isDark ? '#F7F3EC' : 'var(--text)',
              letterSpacing:'-0.01em',
            }}>
              Firi Guent
            </div>
            <div style={{
              fontFamily:"'Scheherazade New',serif",
              fontSize:11, direction:'rtl',
              color: isDark ? 'rgba(200,170,80,.8)' : 'var(--gold)',
              lineHeight:1,
            }}>
              تفسير الأحلام
            </div>
          </div>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex" style={{ alignItems:'center', gap:2 }}>
          {visibleLinks.map(({ to, label, Icon }) => {
            const isActive = pathname === to
            return (
              <Link key={to} to={to} style={{
                display:'flex', alignItems:'center', gap:6,
                padding:'7px 14px', borderRadius:10,
                fontFamily:"'Outfit',sans-serif",
                fontSize:13.5, fontWeight:500, textDecoration:'none',
                transition:'all .2s',
                background: isActive
                  ? (isDark ? 'rgba(255,255,255,.12)' : 'var(--emerald-pale)')
                  : 'transparent',
                color: isActive
                  ? (isDark ? '#BBF7D0' : 'var(--emerald)')
                  : (isDark ? 'rgba(247,243,236,.75)' : 'var(--text-3)'),
              }}>
                <Icon size={13}/>{label}
              </Link>
            )
          })}

          <div style={{ width:1, height:20, background: isDark ? 'rgba(255,255,255,.15)' : 'var(--card-border)', margin:'0 8px' }}/>
          <AccessPill/>

          {user ? (
            <div style={{ display:'flex', alignItems:'center', gap:8, marginLeft:6 }}>
              <span style={{
                fontFamily:"'Outfit',sans-serif",
                fontSize:12,
                color: isDark ? 'rgba(247,243,236,.5)' : 'var(--text-muted)',
                maxWidth:100, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
              }}>
                {user.email?.split('@')[0]}
              </span>
              <button onClick={logout} style={{
                background:'none',
                border:`1px solid ${isDark ? 'rgba(239,68,68,.3)' : 'rgba(220,38,38,.25)'}`,
                borderRadius:8, padding:'5px 12px', cursor:'pointer',
                fontFamily:"'Outfit',sans-serif",
                color:'#DC2626', fontSize:12, fontWeight:500,
              }}>
                Sortir
              </button>
            </div>
          ) : (
            <Link to="/login" style={{
              marginLeft:10, padding:'8px 20px', borderRadius:10,
              fontFamily:"'Outfit',sans-serif",
              fontSize:13, fontWeight:600, textDecoration:'none',
              background: isDark ? 'rgba(139,105,20,.3)' : 'var(--emerald)',
              color: isDark ? '#F7F3EC' : '#F0FDF4',
              border: `1.5px solid ${isDark ? 'rgba(200,170,80,.5)' : 'transparent'}`,
              transition:'all .2s',
            }}>
              Connexion
            </Link>
          )}
        </div>

        {/* Mobile burger */}
        <button
          onClick={() => setOpen(v => !v)}
          className="md:hidden"
          style={{ background:'none', border:'none', cursor:'pointer', padding:8,
            color: isDark ? 'rgba(247,243,236,.8)' : 'var(--text-muted)' }}
        >
          {open ? <X size={22}/> : <Menu size={22}/>}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div style={{
          background: 'var(--card)',
          borderTop: '1px solid var(--card-border)',
          boxShadow: '0 12px 40px rgba(15,29,13,.12)',
          padding:'12px 16px 20px',
        }}>
          {/* Ornement arabesque */}
          <div style={{ textAlign:'center', marginBottom:12, opacity:.5 }}>
            <div style={{ height:1, background:'linear-gradient(to right, transparent, var(--gold-soft), transparent)', marginBottom:8 }}/>
            <span style={{ fontFamily:"'Scheherazade New',serif", fontSize:14, color:'var(--gold)', letterSpacing:4 }}>✦ ✦ ✦</span>
          </div>

          {visibleLinks.map(({ to, label, Icon }) => (
            <Link key={to} to={to} style={{
              display:'flex', alignItems:'center', gap:12,
              padding:'12px 16px', borderRadius:12, marginBottom:4,
              fontFamily:"'Outfit',sans-serif",
              fontSize:15, fontWeight:500, textDecoration:'none',
              color: pathname === to ? 'var(--emerald)' : 'var(--text-2)',
              background: pathname === to ? 'var(--emerald-pale)' : 'transparent',
            }}>
              <Icon size={16}/>{label}
            </Link>
          ))}

          <div style={{ padding:'8px 16px 6px' }}><AccessPill/></div>

          {user ? (
            <button onClick={logout} style={{
              width:'100%', padding:'13px',
              marginTop:10, borderRadius:12,
              fontFamily:"'Outfit',sans-serif",
              background:'#FEF2F2', border:'1px solid #FCA5A5',
              color:'#DC2626', fontSize:14, fontWeight:600, cursor:'pointer',
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>
              Déconnexion · {user.email?.split('@')[0]}
            </button>
          ) : (
            <Link to="/login" className="btn btn-primary" style={{
              width:'100%', justifyContent:'center',
              padding:'13px', marginTop:10, borderRadius:12,
              fontSize:15, display:'flex', alignItems:'center', gap:8,
            }}>
              <Moon size={16}/> Se connecter
            </Link>
          )}
        </div>
      )}
    </header>
  )
}
