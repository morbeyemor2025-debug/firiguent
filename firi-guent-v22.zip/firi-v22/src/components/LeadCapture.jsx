import React, { useState } from 'react'
import { X, Mail, CheckCircle } from 'lucide-react'
import { saveLead } from '../utils/storage.js'
import { waNotFoundLink } from '../utils/constants.js'

const WaIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

export default function LeadCapture({ keyword = '', onClose }) {
  const [mode, setMode] = useState('choice')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [error, setError] = useState('')

  const submit = () => {
    if (!email.includes('@')) { setError('Email invalide.'); return }
    saveLead({ email, phone, keyword, source: 'not_found' })
    setMode('done')
  }

  const waLink = waNotFoundLink(keyword)

  if (mode === 'done') {
    return (
      <div className="card p-7 text-center">
        <CheckCircle size={40} className="mx-auto mb-3" style={{color:'var(--green)'}} />
        <div className="font-display text-xl font-semibold mb-2" style={{color:'var(--text)'}}>Baraka Allahu fikoum 🤲</div>
        <p className="text-sm" style={{color:'var(--text-3)'}}>
          Votre demande a été enregistrée. In sha Allah, Sheikh Momar vous répondra par email avec votre interprétation personnalisée.
        </p>
        {onClose && <button onClick={onClose} className="btn btn-outline mt-4 px-6 py-2 text-sm rounded-xl">Fermer</button>}
      </div>
    )
  }

  return (
    <div className="card p-6 relative">
      {onClose && (
        <button onClick={onClose} className="absolute top-4 right-4 p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-all">
          <X size={16}/>
        </button>
      )}
      <div className="text-center mb-5">
        <div className="text-3xl mb-2">🔍</div>
        <h3 className="font-display text-xl font-semibold mb-1" style={{color:'var(--text)'}}>
          Vous n'avez pas trouvé votre rêve ?
        </h3>
        <p className="text-sm" style={{color:'var(--text-3)'}}>
          {keyword && <><strong>"{keyword}"</strong> — </>}
          Nos experts vous proposeront une interprétation personnalisée.
        </p>
      </div>

      {mode === 'choice' && (
        <div className="space-y-3">
          <a href={waLink} target="_blank" rel="noreferrer"
            className="btn btn-wa w-full py-3.5 rounded-xl justify-center text-base wa-pulse">
            <WaIcon /> Contacter sur WhatsApp
          </a>
          <div className="divider"><span className="text-xs px-2">ou</span></div>
          <button onClick={() => setMode('email')}
            className="btn btn-outline w-full py-3 rounded-xl justify-center text-sm">
            <Mail size={15} /> Recevoir l'interprétation par email
          </button>
        </div>
      )}

      {mode === 'email' && (
        <div className="space-y-3">
          <input type="email" value={email} onChange={e => { setEmail(e.target.value); setError('') }}
            className="field" placeholder="votre@email.com" autoFocus />
          <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
            className="field" placeholder="Votre numéro WhatsApp (optionnel)" />
          {keyword && (
            <div className="p-3 rounded-xl text-sm" style={{background:'var(--blue-pale)', color:'var(--blue-deep)'}}>
              Rêve : <strong>"{keyword}"</strong>
            </div>
          )}
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <div className="flex gap-2">
            <button onClick={() => setMode('choice')} className="btn btn-outline px-4 py-3 rounded-xl text-sm">←</button>
            <button onClick={submit} className="btn btn-primary flex-1 py-3 rounded-xl text-sm">
              <Mail size={15}/> Envoyer ma demande
            </button>
          </div>
          <p className="text-xs text-center" style={{color:'var(--text-muted)'}}>Réponse sous 24h · Confidentialité garantie</p>
        </div>
      )}
    </div>
  )
}
