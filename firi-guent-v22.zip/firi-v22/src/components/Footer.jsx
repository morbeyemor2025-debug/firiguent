import React from 'react'
import { Link } from 'react-router-dom'
import { waDefaultLink, waExpertLink } from '../utils/constants.js'

const WaIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.127.558 4.126 1.533 5.859L.057 23.62a.5.5 0 00.598.65l5.956-1.558A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22a9.944 9.944 0 01-5.13-1.415l-.363-.217-3.773.987.997-3.676-.237-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
  </svg>
)

export default function Footer() {
  return (
    <footer style={{ marginTop:64, borderTop:'1px solid var(--card-border)', background:'#fff' }}>
      <div style={{ maxWidth:900, margin:'0 auto', padding:'40px 20px 24px' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:32, marginBottom:32 }}>

          <div>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12 }}>
              <span style={{ fontSize:20 }}>🌙</span>
              <div style={{ fontFamily:"'Amiri',serif", fontSize:18, fontWeight:700, color:'var(--green)' }}>Firi Guent</div>
            </div>
            <div className="arabic-block" style={{ marginBottom:12, textAlign:'left', padding:'10px 14px', display:'inline-block' }}>
              <div className="arabic-script" style={{ fontSize:'1.1rem' }}>تفسير الأحلام الإسلامي</div>
              <div className="arabic-phonetic" style={{ fontSize:'.8rem' }}>Tafsir al-Ahlam al-Islami</div>
            </div>
            <p style={{ fontSize:13, color:'var(--text-3)', lineHeight:1.6, margin:0 }}>
              Interprétations selon Ibn Sirin & Al-Nabulsi. Halal, confidentiel. Dakar 🇸🇳
            </p>
          </div>

          <div>
            <div className="label-sm" style={{ color:'var(--green)', marginBottom:12 }}>Navigation</div>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {[['/', 'Accueil'], ['/login', 'Connexion'], ['/interpreter', 'Interpréter'], ['/asmaul-husna', "99 Noms d'Allah"], ['/dashboard', 'Mes rêves']].map(([to, label]) => (
                <Link key={to} to={to} style={{ fontSize:13, color:'var(--text-3)', textDecoration:'none' }}
                  onMouseOver={e => e.target.style.color = 'var(--blue)'}
                  onMouseOut={e => e.target.style.color = 'var(--text-3)'}>
                  {label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <div className="label-sm" style={{ color:'var(--green)', marginBottom:12 }}>Contact & Paiement</div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <a href={waDefaultLink()} target="_blank" rel="noreferrer"
                className="btn btn-wa"
                style={{ padding:'10px 16px', fontSize:13, borderRadius:10, justifyContent:'flex-start', gap:8, display:'flex', alignItems:'center' }}>
                <WaIcon/> Paiement Wave
              </a>
              <a href={waExpertLink('')} target="_blank" rel="noreferrer"
                className="btn btn-outline-green"
                style={{ padding:'10px 16px', fontSize:13, borderRadius:10, justifyContent:'flex-start', gap:8, display:'flex', alignItems:'center' }}>
                🕌 Consulter un expert
              </a>
            </div>
          </div>
        </div>

        <div className="arabic-block" style={{ maxWidth:280, margin:'0 auto 16px', padding:'10px 16px' }}>
          <div className="arabic-script" style={{ fontSize:'1.3rem' }}>وَاللَّهُ أَعْلَمُ</div>
          <div className="arabic-phonetic" style={{ fontSize:'.85rem' }}>Wallahu A'lam</div>
          <div className="arabic-translation">Et Allah seul connaît la vérité absolue</div>
        </div>

        <p style={{ textAlign:'center', fontSize:11, color:'var(--text-muted)' }}>
          © {new Date().getFullYear()} Firi Guent · Dakar, Sénégal · Sheikh Momar
        </p>
      </div>
    </footer>
  )
}
