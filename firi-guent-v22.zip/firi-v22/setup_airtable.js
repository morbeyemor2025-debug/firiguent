/**
 * 🛠️ FIRI GUENT — setup_airtable.js v18
 * Lance sur TON PC local : node setup_airtable.js
 *
 * BUGS CORRIGÉS vs versions précédentes :
 * 1. plan → singleSelect (pas singleLineText) pour les automations Airtable
 * 2. status → singleSelect dans PAYMENTS
 * 3. Champs user_email + ref ajoutés dans PAYMENTS (optionnels)
 * 4. Champs user_email ajouté dans INTERPRETATIONS (optionnel)
 * 5. BASE_ID correct : appq95FX5MCVrrVWJ
 */

const TOKEN   = 'pat44JBegA9gLiN7l.c87d07601f5d85124ba32010815cec3897223fa4fe5bfc7aaacd3bc14c6891af'
const BASE_ID = 'appq95FX5MCVrrVWJ'
const API_META = `https://api.airtable.com/v0/meta/bases/${BASE_ID}`
const HEADERS  = { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' }

// ─── Schéma complet requis ────────────────────────────────────────
const SCHEMA = {
  USERS: [
    { name: 'email',            type: 'email'                                                        },
    { name: 'phone',            type: 'phoneNumber'                                                  },
    { name: 'plan',             type: 'singleSelect', options: { choices: [
      { name: 'free',           color: 'grayLight2' },
      { name: 'one_time',       color: 'blueLight2'  },
      { name: 'subscription',   color: 'greenLight2' },
    ]}},
    { name: 'credits',          type: 'number',       options: { precision: 0 }                      },
    { name: 'free_used',        type: 'checkbox',     options: { icon: 'check', color: 'greenBright' }},
    { name: 'subscription_end', type: 'date',         options: { dateFormat: { name: 'iso' } }        },
  ],
  PAYMENTS: [
    { name: 'amount',           type: 'number',       options: { precision: 0 }                      },
    { name: 'status',           type: 'singleSelect', options: { choices: [
      { name: 'pending',        color: 'yellowLight2' },
      { name: 'validated',      color: 'greenLight2'  },
      { name: 'rejected',       color: 'redLight2'    },
    ]}},
    { name: 'user_email',       type: 'email'                                                        },
    { name: 'ref',              type: 'singleLineText'                                               },
  ],
  INTERPRETATIONS: [
    { name: 'dream_text',       type: 'multilineText'                                               },
    { name: 'result',           type: 'multilineText'                                               },
    { name: 'user_email',       type: 'email'                                                        },
  ],
}

async function api(url, method = 'GET', body = null) {
  const opts = { method, headers: HEADERS }
  if (body) opts.body = JSON.stringify(body)
  const res  = await fetch(url, opts)
  const data = await res.json()
  return { ok: res.ok, status: res.status, data }
}

async function getTables() {
  const { ok, data } = await api(`${API_META}/tables`)
  if (!ok) throw new Error(`Impossible de lire les tables : ${data?.error?.message ?? JSON.stringify(data)}`)
  return data.tables ?? []
}

async function addField(tableId, tableName, field) {
  const { ok, data } = await api(`${API_META}/tables/${tableId}/fields`, 'POST', field)
  if (!ok) {
    const msg = data?.error?.message ?? ''
    if (/duplicate|already exist/i.test(msg)) {
      console.log(`   ✓  "${field.name}" déjà présent`)
    } else {
      console.warn(`   ⚠️  "${field.name}" → ${msg}`)
    }
  } else {
    console.log(`   ✅ "${field.name}" créé`)
  }
}

async function addLinkedField(tableId, tableName, fieldName, linkedTableId) {
  const { ok, data } = await api(`${API_META}/tables/${tableId}/fields`, 'POST', {
    name: fieldName, type: 'multipleRecordLinks', options: { linkedTableId }
  })
  if (!ok) {
    const msg = data?.error?.message ?? ''
    if (/duplicate|already exist/i.test(msg)) {
      console.log(`   ✓  "${fieldName}" (linked) déjà présent`)
    } else {
      console.warn(`   ⚠️  "${fieldName}" → ${msg}`)
    }
  } else {
    console.log(`   ✅ "${fieldName}" (linked → USERS) créé`)
  }
}

async function createTable(name) {
  const { ok, data } = await api(`${API_META}/tables`, 'POST', {
    name, fields: [{ name: 'Name', type: 'singleLineText' }]
  })
  if (!ok) throw new Error(`Création "${name}" : ${data?.error?.message ?? JSON.stringify(data)}`)
  return data
}

async function main() {
  console.log('\n🌙 FIRI GUENT — Setup Airtable v18')
  console.log(`📦 Base  : ${BASE_ID}`)
  console.log(`🔑 Token : ${TOKEN.slice(0, 22)}…\n`)

  let tables
  try {
    tables = await getTables()
  } catch (e) {
    console.error('❌', e.message)
    console.error('\n💡 Vérifiez que votre token a ces scopes :')
    console.error('   data.records:read  data.records:write')
    console.error('   schema.bases:read  schema.bases:write')
    process.exit(1)
  }

  const tableMap = {}
  for (const t of tables) tableMap[t.name] = t
  console.log('📋 Tables existantes :', Object.keys(tableMap).join(', ') || '(aucune)')
  console.log()

  // Créer les tables manquantes
  for (const name of ['USERS', 'PAYMENTS', 'INTERPRETATIONS']) {
    if (!tableMap[name]) {
      console.log(`🔨 Création "${name}"…`)
      try {
        const t = await createTable(name)
        tableMap[name] = t
        console.log(`   ✅ Table créée (id: ${t.id})\n`)
      } catch (e) {
        console.error(`   ❌ ${e.message}\n`)
      }
    } else {
      console.log(`✓  "${name}" (id: ${tableMap[name].id})`)
    }
  }
  console.log()

  // Ajouter les champs manquants
  for (const tableName of ['USERS', 'PAYMENTS', 'INTERPRETATIONS']) {
    const table = tableMap[tableName]
    if (!table) { console.log(`⏭️  "${tableName}" introuvable\n`); continue }
    console.log(`🔧 "${tableName}" (id: ${table.id})`)

    const { data: fd } = await api(`${API_META}/tables/${table.id}/fields`)
    const existing = (fd?.fields ?? []).map(f => f.name.toLowerCase())
    console.log(`   Existants : ${existing.join(', ')}`)

    for (const field of (SCHEMA[tableName] ?? [])) {
      if (existing.includes(field.name.toLowerCase())) {
        console.log(`   ✓  "${field.name}" OK`)
      } else {
        await addField(table.id, tableName, field)
      }
    }

    // Linked record user_id pour PAYMENTS et INTERPRETATIONS
    if (tableName !== 'USERS') {
      const usersTable = tableMap['USERS']
      if (!usersTable) {
        console.warn('   ⚠️  USERS introuvable — user_id ignoré')
      } else if (existing.includes('user_id')) {
        console.log('   ✓  "user_id" OK')
      } else {
        await addLinkedField(table.id, tableName, 'user_id', usersTable.id)
      }
    }
    console.log()
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('✅  SETUP TERMINÉ')
  console.log()
  console.log('Structure finale :')
  console.log('  USERS           → email · phone · plan(singleSelect) · credits · free_used · subscription_end')
  console.log('  PAYMENTS        → amount · status(singleSelect) · user_email · ref · user_id(linked)')
  console.log('  INTERPRETATIONS → dream_text · result · user_email · user_id(linked)')
  console.log()
  console.log('Prochaine étape : configurer les 2 automations Airtable')
  console.log('Puis : déployer le ZIP sur Netlify')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
}

main().catch(e => { console.error('\n💥', e.message); process.exit(1) })
